#include<bits/stdc++.h>
#define all(cont) cont.begin(),cont.end()
#define traverse_cont(cont,itr) for(typeof(cont.begin()) itr= cont.begin() ;itr!= cont.end() ;itr++)
using namespace std;

void print_vec(vector<int> *v)
{
	for(int i=0;i< (v->size());i++)
	{
		// cout << *(v+i) << " ";
		cout << v->at(i) << " ";
	}
}
int main()
{
	vector<int> v={1,5,8,3,9,2,4,3},v1,v2(20,1),v3(5),v4[10];
	vector<int> v5(v.begin(),v.begin()+5);              // v[0],......,v[5]
	v1=v;
	vector<int> :: iterator i;

	int arr[]={1,4,8,6,2,3,9};
	vector <int> v6(arr,arr+5);       // arr[0],.....,arr[5]

	/*
	for(int i=0;i<v.size();i++)
	{
		//cout << v.at(i) << " ";
		//cout << v[i] << " ";
	}

	v.resize(9);
	cout << v.front() << " " << v.back() << endl;

	v.assign(3,7);
	v.assign(arr,arr+6);
	v.assign(v3.begin(),v3.end()+3);

	v.push_back(5);
	v.emplace_back(12);
	v.emplace(v.begin()+4,18);

	v.insert(v.begin()+2,10);
	v.insert(v.begin()+2,5,10);
	v.insert(v.end(),v2.begin(),v2.begin()+2);

	v.pop_back();
	v.erase(v.begin()+3);                                  //auto itr=remove(v.begin(),v.end(),8); don't use remove()
	v.erase(v.begin()+1,v.end()-1);
	v.clear();
	v2.swap(v); 
	

	cout << *max_element(v.begin(),v.end()) << endl;
	cout << *min_element(v.begin(),v.end()) << endl;
	cout << max_element(v.begin(),v.end())-v.begin()<< endl;
	cout << min_element(v.begin(),v.end())-v.begin()<< endl;

	int index,total_count;

	index= find(v.begin(),v.end(),3)-v.begin();
	total_count=count(v.begin(),v.end(),3);
	
	sort(v.begin(),v.end());
	sort(v.rbegin(),v.rend());
	reverse(v.begin(),v.end()); */

	for(i=v.begin();i!=v.end();i++)
	{
		cout << *i << " ";
	}

	//print_vec(&v);

	/*cout << endl;
	for(auto i : v)
	{
		cout << i << " ";
	}*/
	
	return 0;
}


/*
	sort(all(v));
	vector<int> :: iterator i;
	tr(v,i)
	{
		cout << *i << " ";
	}
	cout << endl; 
*/