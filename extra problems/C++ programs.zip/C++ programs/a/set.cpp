#include<bits/stdc++.h>
#define all(cont) cont.begin(),cont.end()
using namespace std;
int main()
{
	set<int> s={1,5,4,2,3,7,6,9,5},s1,s2;
	set<int> s3(s);
	s1=s;
	s2={10,18,13,14,19,15,16};
	/*s.erase(4);
	auto itr=s.begin();
	advance(itr,3);
	s.erase(itr);
	auto itr1=s.begin();
	advance(itr1,2);
	s.erase(itr1,prev(s.end(),1));
	s.clear();

	s.emplace(10);
	s.insert(8);
	auto itr2=s.begin();
	advance(itr2,3);
	s.insert(itr2,100);                // no matter what pos u mention ,it will insert acc. to it's position in increaing order
	s.insert(all(s2));                // no matter what pos u mention ,they will be inserted acc. to their position in increaing order

	cout << distance(s.begin(),s.find(5))<< endl;
	cout << s.count(3) << endl   ;    //return 0 or 1 acc to elemnt present or not
	cout << *(s.upper_bound(3)) << endl;
	cout << *(s.lower_bound(3)) << endl;

	cout << distance(s.begin(),s.emplace_hint(s.begin(),8)) << endl; // "emplace_hint()" return itr points to pos where key is insrted
	*/

	for(auto i: s)
	{
		cout << i << " ";
	}
}