#include<bits/stdc++.h>
using namespace std;
int main()
{
	pair<int,char>p(1,'a'),p2;
	pair <int,char>p3(p);
	p2=make_pair(3,'c');
	p2.swap(p);
	cout << p.first << " " << p.second << endl;
	cout << p2.first << " " << p2.second << endl;
	 // == , < ,> ,!= ,>=,<= read from notebbok
	return 0;
}
