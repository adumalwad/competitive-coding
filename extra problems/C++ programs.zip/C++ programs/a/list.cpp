#include<bits/stdc++.h>
#define all(cont) cont.begin(),cont.end()
using namespace std;
int main()
{
	list <int> l={1,3,5,4,2,6,8,7,9,0,4},l1,l2;
	list <int> l4={18,3,14,25,43,12,0,98,75};
	l2={10,11,12,13,14,15,16,17,18,19};
	/*list<int>l3(l);
	l1=l;*/

	/*
	l4.swap(l);
	l.assign(3,55);
	cout << l.front() << " " << l.back() << endl;

	auto itr=l.begin();
	advance(itr,2);
	itr=l.insert(itr,10);           // here "l.begin()+2" will not work
	itr=l.insert(itr,3,15);
	itr=l.insert(itr,all(l4));
	itr=l.emplace(itr,299);
	l.emplace_back(20);
	l.push_front(213);
	l.push_back(20);
	
	l.remove(6);                       // read about "remove_if()"
	auto itr1=l.begin();
	itr1=next(itr1,2);         // "next()" returns iterator
	itr1=l.erase(itr1);
	l.erase(itr1,l.end());
	l.pop_front();
	l.pop_back();
	l.clear();

	auto pos=l.begin();
	advance(pos,2);
	auto x=l2.begin();
	advance(x,2);
	auto y= next(x,5);
	l.splice(pos,l2);            // all l2-> l1
	l.splice(pos,l2,x);			 // single element of l2 pointed by "x" -> l1
	l.splice(pos,l2,x,y);		 // range from [x,y) of l2 ->l1

	l.merge(l2);

	l.reverse();                      // "reverse(l.begin(),l.end());" will also work
	l.sort();                        // here "sort(l.begin(),l.end())" will not

	cout << *max_element(l.begin(),l.end())<< endl;
	cout << *min_element(l.begin(),l.end())<< endl;
	cout << distance( l.begin(),max_element(l.begin(),l.end()))<< endl;    // "max_element(l.begin(),l.end()) - l.begin()" will not work
	cout << distance( l.begin(),min_element(l.begin(),l.end()))<< endl;

	cout <<accumulate(l.begin(),l.end(),0)<<endl;
	cout << count(l.begin(),l.end(),4) << endl;
	auto itr2=find( l.begin(),l.end(),*max_element(l.begin(),l.end()) )
	cout << distance(itr2,l.begin());
	*/
	
	for(auto i:l)
	{
		cout << i << " ";
	}
	
}