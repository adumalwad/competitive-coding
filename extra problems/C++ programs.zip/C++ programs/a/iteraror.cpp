#include<bits/stdc++.h>
using namespace std;
int main()
{
	// Constant container needd constant iterator
	vector<int> v={2,1,4,6,9,0,7,3,5};
	vector<int> :: iterator itr;
	vector<int> :: iterator itr1=v.begin();
	auto itr2=v.end();

	/*
	advance(itr1,3);                //v.begin()+3
	itr1=next(itr1,3);              // v.begin()+3

	itr2=prev(itr2,2);              //v.end()-2
	*/
	cout << *itr2;
	/*for(itr=v.begin();i!=v.end();i++)
	{
		cout << *i << " ";
	}*/

	return 0;
}
