#include<stdio.h>
void sort_arr(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i]<a[j])
			{
				int s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
}
void freq(int a[],int n)
{
	while(n!=1)
	{
		//printf("n=%d\n",n);
		int c[n];
		sort_arr(a,n);
		int j=0;
		c[0]=1;
		for(int i=1;i<n;i++)
		{
			if(a[i]==a[i-1])
			{
				c[j]++;	
			}
			else
			{
				j++;
				c[j]=1;
			}
		}
		n=j+1;
		for(int i=0;i<n;i++)
		{
			a[i]=c[i];
			printf("%d ",c[i]);
		}
		printf("\n");
	}
	printf("%d",n);
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	freq(a,n);
	return 0;
}
