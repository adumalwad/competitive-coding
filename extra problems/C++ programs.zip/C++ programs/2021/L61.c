#include<stdio.h>
#include<math.h>
int summ(int m)
{
	int sum=0;
	while(m!=0)
	{
		sum+=m%10;
		m/=10;
	}
	return sum;
}
int countd(int m)
{
	int k=0;
	while(m!=0)
	{
		k++;
		m/=10;
	}
	return k;
}
int main()
{
	int q,n;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%d",&n);
		for(int m=n;m>=1;m--)
		{
			int sum=summ(m);
			if((sum+m)==n)
			{
				printf("%d = %d + (",n,m);
				int c=countd(m);
				while((m/10)!=0)
				{
					int k1=pow(10,c-1);
					printf("%d+",m/k1);
					c--;
					m%=k1;
				}
				printf("%d)\n",m);
				break;
			}	
		}
	}
	return 0;
}
