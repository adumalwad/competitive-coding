#include<stdio.h>
void sortarr(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i]<a[j])
			{
				int swap=a[i];
				a[i]=a[j];
				a[j]=swap;
			}
		}
	}
}
int main()
{
	int a[100],i=0;
	scanf("%d",&a[0]);
	while(a[i]!=(-1))
	{
		i++;
		scanf("%d",&a[i]);
	}
	sortarr(a,i);
	/*for(int j=0;j<i;j++)
	{
		printf("%d ",a[j]);
	}*/
	float m1,m2;
	if(i%2==0)
	{
		printf("Median is %.2f\n",(float)(a[i/2]+a[(i/2)-1])/2);	
		if(i%4==0)
		{
			m1=	(float)(a[i/4]+a[(i/4)-1])/2;
			m2=(float)(a[(i/2)+(i/4)]+a[(i/2)+(i/4)-1])/2;
		}
		else
		{
			m1=(float)a[(i/4)];
			m2=(float)a[(i/2)+(i/4)];
		}
	}
	else
	{
		printf("Median is %.2f\n",(float)a[i/2]);	
		if((i-1)%4==0)
		{
			m1=	(float)(a[i/4]+a[(i/4)-1])/2;
			m2=(float)(a[(i/2)+(i/4)]+a[(i/2)+(i/4)+1])/2;
		}
		else
		{
			m1=(float)a[(i/4)];
			m2=(float)a[(i/2)+(i/4)+1];
		}
	}
	//printf("m1=%.2f m2=%.2f\n",m1,m2);
	printf("IQR is %.2f",m2-m1);
	return 0;
}
