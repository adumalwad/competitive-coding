#include<stdio.h>

void copy_arr(int a[],int b[],int n)
{
	for(int i=0;i<n;i++)
	{
		b[i]=a[i];
	}
}

void print_arr(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}


void sort_arr(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;i++)
		{
			if(a[i]<a[j])
			{
				int swap=a[i];
				a[i]=a[j];
				a[j]=swap;
			}
		}
	}
}
int same_arr(int a[],int b[],int n)
{
	int c[n];
	copy_arr(a,c,n);
	sort_arr(c,n);
	for(int i=0;i<n;i++)
	{
		if(c[i]!=b[i])
		{
			return 0;
		}
	}
	return 1;
}
int remove_mod(int a[],int n)
{
	int b[n],c[n],z=0,maxc,minb;
	copy_arr(a,b,n);
	for(int i=0;i<n;i++)
	{
		if(b[i]==(-1))
		{
			continue;
		}
		else
		{
			//printf("%d \n",b[i]);
			b[z]=b[i];
			c[z]=1;
			//printf("%d %d\n",b[z],c[z]);
			for(int j=i+1;j<n;j++)
			{
				if(b[j]==b[i])
				{
					b[j]=-1;
					c[z]++;
				}
			}
			//printf("%d %d\n",b[k],c[k]);
			if(z==0)
			{
				maxc=c[z];
				minb=b[z];
			}
			else
			{
				if(c[z]>maxc)
				{
					maxc=c[z];
					minb=b[z];
				}
				else if((c[z]==maxc) && (b[z]<minb))
				{
					maxc=c[z];
					minb=b[z];
				}
			}
			z++;	
		}
	}
//	printf("%d %d\n",minb,maxc);
	int k=0;
	for(int i=0;i<n;i++)
	{
		if(a[i]!=minb)
		{
			a[k]=a[i];
			k++;
		}
	}
	return k;
}
int append_mode(int a[],int k,int n,int lim)
{
	int e,sum=0;
	while(k!=n)
	{
		int p=1;
		for(int i=0;i<k;i++)
		{
			p*=a[i];
		}
		a[k]=(10*p)%lim;
		k++;
	}
	return k;
}
int main()
{
	int n,m,lim;
	scanf("%d %d %d",&n,&m,&lim);
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		//b[i]=a[i];
	}
	copy_arr(a,b,n);
	for(int v=0;v<m;v++)
	{
		int k=remove_mod(a,n);
		int f=append_mode(a,k,n,lim);
		print_arr(a,n);
		int s=0;                         //same_arr(a,b,n) shuld be used here
		if(s==1)
		{
			break;
		}
	}
	return 0;
}
//same_arr(a,b,n);
