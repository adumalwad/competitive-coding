#include<stdio.h>
int isdivisible(float a,float b,float c)
{
	if(((a/b)==c) || ((b/a)==c) || ((b/c)==a) || ((c/b)==a) || ((a/c)==b) || ((c/a)==b) )
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	int q;
	float a,b,c;
	scanf("%d\n",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%f %f %f",&a,&b,&c);
		if(isdivisible(a,b,c)==1)
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}
	}
	return 0;
}
