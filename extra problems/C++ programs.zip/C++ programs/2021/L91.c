#include<stdio.h>
int read(char s[],int n)
{
	int i=0;
	char ch;
	ch=getchar();
	while((ch!='\n')&&(ch!= EOF))
	{
		s[i]=ch;
		i++;
		ch=getchar();
		if(i==(n-1))
		{
			break;
		}
	}
	s[i]='\0';
	return i;
}
int main()
{
	char s[100];
	int len=read(s,100);
	for(int i=0;i<len;i++)
	{
		//printf("%c",s[i]);
		if(s[i]!=' ')
		{
			printf("%c",'a'+'z'-s[i]);
		}
		else
		{
			printf("%c",s[i]);
		}
	}
	
	return 0;
}
