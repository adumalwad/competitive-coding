#include<stdio.h>
int main()
{
	int a[100],i=0;
	scanf("%d",&a[0]);
	while(a[i]!=(-1))
	{
		i++;
		scanf("%d",&a[i]);
	}
	return 0;
}
