#include<stdio.h>
int count1(int st,int k)
{
	if(k==1)
	{
		return 1;
	}
	switch(st)
	{
		case 1:
		{
			return count1(2,k-1)+count1(4,k-1);
			break;
		}
		case 2:
		{
			return count1(1,k-1)+count1(3,k-1)+count1(5,k-1);
			break;
		}
		case 3:
		{
			return count1(2,k-1)+count1(6,k-1);
			break;
		}
		case 4:
		{
			return count1(1,k-1)+count1(5,k-1)+count1(7,k-1);
			break;
		}
		case 5:
		{
			return count1(2,k-1)+count1(4,k-1)+count1(6,k-1)+count1(8,k-1);
			break;
		}
		case 6:
		{
			return count1(3,k-1)+count1(5,k-1)+count1(9,k-1);
			break;
		}
		case 7:
		{
			return count1(4,k-1)+count1(8,k-1);
			break;
		}
		case 8:
		{
			return count1(5,k-1)+count1(7,k-1)+count1(9,k-1)+count1(0,k-1);
			break;
		}
		case 9:
		{
			return count1(6,k-1)+count1(8,k-1);
			break;
		}
		case 0:
		{
			return count1(8,k-1);
			break;
		}
	}
/*	if(st==1)
	{
		count1(2,k-1)+count1(4,k-1);
	}*/
}
int main()
{
	int n,k;
	scanf("%d %d",&n,&k);
	printf("%d",count1(n,k));
	return 0;	
}
