#include<stdio.h>
#include<string.h>
void sort(char s[],int n)
{
	char c;
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if((s[i]-s[j])>0)
			{
				c=s[i];
				s[i]=s[j];
				s[j]=c;
			}
		}
	}
}
int main()
{
	char str1[10],str2[10];
	scanf("%s %s",str1,str2);
//	printf("%s %d %s %d\n",str1,strlen(str1),str2,strlen(str2));
	sort(str1,strlen(str1));
	sort(str2,strlen(str2));
	//printf("%s %d %s %d",str1,strlen(str1),str2,strlen(str2));
	if(strcmp(str1,str2)<0)
	{
		printf("1");
	}
	else
	{
		printf("-1");	
	}
	return 0;
}
