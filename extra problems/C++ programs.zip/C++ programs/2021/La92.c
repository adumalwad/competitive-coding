#include<stdio.h>
void sort_arr(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(a[i]>a[j])
			{
				int s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}	
}
int find_freqn(int a[],int b[],int c[],int d[],int n)
{
	int j=0;
	b[0]=a[0];
	c[0]=1;
	d[0]=1;
	for(int i=1;i<n;i++)
	{
		if(a[i]==a[i-1])
		{
			c[j]++;
			d[j]++;
		}
		else
		{
			j++;
			b[j]=a[i];
			d[j]=1;
			c[j]=1;
		}
	}
	return j;
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],b[n],c[n],d[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	sort_arr(a,n);
	int t=find_freqn(a,b,c,d,n);
	/*for(int i=0;i<=t;i++)
	{
		printf("%d %d\n",b[i],c[i]);
	}*/
	sort_arr(d,t+1);
	/*for(int i=0;i<=t;i++)
	{
		printf("%d ",d[i]);
	}
	printf("\n");*/
	for(int i=0;i<=t;i++)
	{
		//printf("d=%d\n",d[i]);
		int tmp[t],p=0;
		if(i==0)
		{
			for(int j=0;j<=t;j++)
			{
				if(c[j]==d[i])
				{
				//	printf("%d %d\n",c[j],b[j]);
					tmp[p]=b[j];
					//printf("%d ",tmp[p]);
					p++;
				}
			}
			sort_arr(tmp,p);
			for(int i=0;i<p;i++)
			{
				printf("%d ",tmp[i]);
			}
			printf("\n");
		}
		else
		{
			if(d[i]!=d[i-1])
			{
				for(int j=0;j<=t;j++)
				{
					if(c[j]==d[i])
					{
					//	printf("%d %d\n",c[j],b[j]);
						tmp[p]=b[j];
						//printf("%d ",tmp[p]);
						p++;
					}
				}
				sort_arr(tmp,p);
				for(int i=0;i<p;i++)
				{
					printf("%d ",tmp[i]);
				}
				printf("\n");
			}
		}
	}
	return 0;
}
