#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	if((n==1)||(n==2))
	{
		printf("%d",n);
	}
	else
	{
		for(int i=n;i>=2,i++)
		{
			int tr=1
			for(int j=2;j<=(sqrt(n)+1),j++)
			{
				if(i%j==0)
				{
					tr=0;
					break;
				}
				if(tr==1)
				{
					printf("%d",i);
					return 0;
				}
			}
		}
	}
	return 0;
}
