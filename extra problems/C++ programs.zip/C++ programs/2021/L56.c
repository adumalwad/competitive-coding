#include<stdio.h>
#include<math.h>
int main()
{
	double x1,y1;
	int d,c=0;
	scanf("%lf %lf",&x1,&y1);
	scanf("%d",&d);
	printf("%lf %lf %d\n",x1,y1,d);
	int i=0;
	while(i!=4)
	{
		x1*=10;
		i++;
	}
	i=0;
	while(i!=4)
	{
		y1*=10;
		i++;
	}
	//long long int x=x1*pow(10,5),y=y1*pow(10,5);
//	printf("%d %d \n",(int)x1,(int)y1);
	long long int x=(int)x1,y=(int)y1;
	printf("%lld %lld \n",x,y);
	return 0;
}
