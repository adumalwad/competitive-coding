#include<stdio.h>
int main()
{
	int q;
	scanf("%d\n",&q);
	for(int i=0;i<q;i++)
	{
		int h,p,hp,hp1,count=0;
		scanf("%d\n",&h);
		scanf("%d\n",&p);
		scanf("%d",&hp);
		for(int i=1;i<p;i++)
		{
			scanf("%d",&hp1);
			if(hp1<hp)
			{
				h-=(hp-hp1);
			}
			hp=hp1;
		}
		printf("%d\n",h);
		if(h<=0)
		{
			printf("No\n");
		}
		else
		{
			printf("Yes\n");
		}
	}
	return 0;
}
