#include<stdio.h>
#include<math.h>
int prod(int m)
{
	int p=1;
	while(m!=0)
	{
		p*=(m%10);
		m/=10;
	}
	return p;
}
int countd(int m)
{
	int k=0;
	while(m!=0)
	{
		k++;
		m/=10;
	}
	return k;
}
int iszero(int m)
{
	while(m!=0)
	{
		if(m%10==0)
		{
			return 1;
		}
		m/=10;
	}
	return 0;
}
int main()
{
	int q,n;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%d",&n);
		int k1=0;
		//printf("%d %d\n",n,prod(n));
		//printf("%d %d\n",n,iszero(n));
		for(int m=n;m>=1;m--)
		{
			if(iszero(m)==0)
			{
				int p=prod(m);
				if((p+m)==n)
				{	k1++;
					printf("%d = %d + ",n,m);
					int c=countd(m);
					while((m/10)!=0)
					{
						int k1=pow(10,c-1);
						printf("%d*",m/k1);
						c--;
						m%=k1;
					}
					printf("%d\n",m);
					break;
				}	
			}
		}
		if(k1==0)
		{
			printf("No Solution");
		}
					
	}
	return 0;
}
