#include<stdio.h>
#include<string.h>
void sort(char str[],int n)
{
	char s;
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(str[i]>str[j])
			{
				s=str[i];
				str[i]=str[j];
				str[j]=s;
			}	
		}
	}
}
int main()
{
	char str1[100],str2[100];
	scanf("%s %s",str1,str2);
	sort(str1,strlen(str1));
	sort(str2,strlen(str2));
	//printf("%s %s\n",str1,str2);
	if(strcmp(str1,str2)==0)
	{
		printf("yes");
	}
	else
	{
		printf("no");
	}
	return 0;
}
