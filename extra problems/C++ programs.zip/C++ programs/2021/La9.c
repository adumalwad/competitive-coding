#include<stdio.h>
#include<string.h>
int main()
{
	int n;
	scanf("%d",&n);
	char a[n][20],s[20];
	for(int i=0;i<n;i++)
	{
		scanf("%s[^\n]",a[i]);
	}
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(strcasecmp(a[i],a[j])>0)
			{
				strcpy(s,a[i]);
				strcpy(a[i],a[j]);
				strcpy(a[j],s);
			}
		}
	}
	/*for(int i=0;i<n;i++)
	{
		printf("%s ",a[i]);
	}*/
	if(n%2==0)
	{
		printf("%s",a[(n/2)-1]);
	}
	else
	{
		printf("%s",a[(n/2)]);
	}
	return 0;
}
