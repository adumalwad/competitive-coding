#include<stdio.h>
void sort(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(a[i]>a[j])
			{
				int s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
}
int freqn(int a[],int b[],int c[],int d[],int n)
{
	sort(a,n);
	int j=0;
	b[j]=a[j];
	c[j]=1;
	d[j]=1;
	for(int i=1;i<n;i++)
	{
		if(a[i]==a[i-1])
		{
			c[j]++;
			d[j]++;
		}
		else
		{
			j++;
			c[j]=1;
			d[j]=1;
			b[j]=a[i];
		}
	}
	sort(d,j+1);
	return j+1;
		
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],b[n],c[n],d[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int t=freqn(a,b,c,d,n);
	for(int i=0;i<t;i++)
	{
		printf("%d %d %d\n",b[i],c[i],d[i]);
	}
	if(t%2==0)
	{
		int med=d[(t/2)-1];
		for(int i=0;i<t;i++)
		{
			if(c[i]==med)
			{
				printf("%d",b[i]);
				break;
			}
		}
	}
	else
	{
		int med=d[(t/2)];
		for(int i=0;i<t;i++)
		{
			if(c[i]==med)
			{
				printf("%d",b[i]);
				break;
			}
		}
	}
	return 0;
}
