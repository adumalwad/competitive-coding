#include<stdio.h>
int main()
{
	char ch;
	int nt=0,ns=0,nf=0,ni=0,nn=0,nd=0,np=0;
	scanf("%c",&ch);
	while(ch!='O')
	{
		if ( (ch!='T') && (ch!='S') && (ch!='F') && (ch!='I') && (ch!='N') && (ch!='D') && (ch!='P') )
		{
			printf("INVALID");
			return 0;
		}
		switch(ch)
		{
			case 'T':
			{
				nt++;
				break;
			}
			case 'S':
			{
				ns++;
				break;
			}
			case 'F':
			{
				nf++;
				break;
			}
			case 'I':
			{
				ni++;
				break;
			}
			case 'N':
			{
				nn++;
				break;
			}
			case 'D':
			{
				nd++;
				break;
			}
			case 'P':
			{
				np++;
				break;
			}
		}
		scanf("%c",&ch);
	}
	if( (nt==3) && (ns==1) && (nf<=6) && (ni>=3) && (nn>=3) && (nd<=30))
	{
		printf("DOCTOR");
	}
	else
	{
		printf("NOT A DOCTOR");
	}
	return 0;
}
