#include<stdio.h>
int main()
{
	int h,a,k=0;
	scanf("%d %d",&h,&a);
	int nh[h],na[a],nc[h+a];
	for(int i=0;i<h;i++)
	{
		scanf("%d",&nh[i]);
		if(nh[i]>=100)
		{
			printf("%d ",nh[i]);
			k++;
		}
	}
	
	for(int i=0;i<a;i++)
	{
		scanf("%d",&na[i]);
		if(na[i]>=100)
		{
			printf("%d ",na[i]);
			k++;
		}
	}
	printf("\n%.1f%%",((float)(k)/(h+a))*100);
	return 0;
}
