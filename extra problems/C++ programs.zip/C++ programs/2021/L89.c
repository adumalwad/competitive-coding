#include<stdio.h>
#include<math.h>
int count1(int n)
{
	if(n==1)
	{
		return 3;
	}
	if(n==2)
	{
		return 8;
	}
	else
	{
		return (count1(n-1)-count1(n-2))*3+count1(n-2)*2;
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d",count1(n));
	return 0;
}
