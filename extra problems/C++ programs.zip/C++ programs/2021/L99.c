#include<stdio.h>
#include<string.h>
void sort(char a[],int n)
{
	char s;
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(a[i]>a[j])
			{
				s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
}
int fact(int n)
{
	int p=1;
	if((n==0)||(n==1))
	{
		return 1;
	}
	while(n!=1)
	{
		p*=n;
		n--;
	}
	return p;
}
int rank(char a[],char b[],int n)
{
	int count=0,r=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
		//	printf("a=%c b=%c count=%d\n",a[i],b[j],count);
			if(b[j]=='1')
			{
				continue;
			}
			else if(a[i]==b[j])
			{
				b[j]='1';
				count++;
				break;
			}
			else if(a[i]!=b[j])
			{
			//	printf("a[i]=%c b[j]=%c count=%d\n",a[i],b[j],count);
				r+=fact(n-count-1);
			}
		}
	}
	return r;
}
int main()
{
	char a[7],b[7];
	scanf("%s",a);
	int n=strlen(a);
	strcpy(b,a);
	sort(a,n);
	printf("%d",rank(b,a,n)+1);
//	printf("%s %s",a,b);
	return 0;
}
