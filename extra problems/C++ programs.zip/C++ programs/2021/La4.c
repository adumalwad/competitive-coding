#include<stdio.h>
int main()
{
	int m,n,max,maxi=0,maxj=0,min,mini=0,minj=0;
	scanf("%d %d",&n,&m);
	int a[n][m];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
			if((i==0)&&(j==0))
			{
				max=a[0][0];
				min=a[0][0];
			}
			else
			{
				if(a[i][j]>max)
				{
					max=a[i][j];
					maxi=i;
					maxj=j;
				}
				else if(a[i][j]<min)
				{
					min=a[i][j];
					mini=i;
					minj=j;
				}
			}
		}
	}
	printf("%d",max+min+a[maxi][maxj+1]+a[mini][minj-1]);
	return 0;
}
