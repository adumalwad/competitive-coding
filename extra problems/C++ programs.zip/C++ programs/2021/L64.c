#include<stdio.h>
int isvalid(int a,int b,int c)
{
	if((a>=b) && (a>=c) && (a>=(b+c)))
	{
		return 0;
	}
	else if((b>=a) && (b>=c) && (b>=(a+c)))
	{
		return 0;
	}
	else if((c>=a) && (c>=b) && (c>=(a+b)))
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
int main()
{
	int a,b,c;
	scanf("%d",&a);
	while(a!=(-1))
	{
		scanf("%d %d",&b,&c);
		if(isvalid(a,b,c)==1)
		{
			printf("yes\n");
		}
		else
		{
			printf("No\n");
		}
		scanf("%d",&a);
	}
	return 0;
}
