#include<stdio.h>
int main()
{
	int n,i,j;
	char ch,k;
	scanf("%d\n",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			scanf("%c",&ch);
			if((i==0) && (j==0))
			{
				if(ch=='0')
				{
					printf("not special diagonal matrix");
					return 0;
				}
				else
				{
					k=ch;
				}
			}
			else if((i!=j) && (ch!='0'))
			{
				printf("not special diagonal matrix");
				return 0;
			}
			else if((i==j) && (i>=1) && (ch!=k))
			{
				printf("not special diagonal matrix");
				return 0;
			}
		}
		if(i<n-1)
		{
			scanf("%c\n",&ch);
		}
		else
		{
			scanf("%c",&ch);
		}
		if((i!=j) && (ch!='0'))
		{
			printf("not special diagonal matrix");
			return 0;
		}
		else if((i==j) && (i>=1) && (ch!=k))
		{
			printf("not special diagonal matrix");
			return 0;
		}
	}
	printf("special diagonal matrix");
	return 0;
}

