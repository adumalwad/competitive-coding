#include<stdio.h>
#include<string.h>
int ispalin(char a[],int n)
{
	if(n==1)
	{
		return 1;
	}
	else
	{
		for(int i=0;i<n;i++)
		{
			if(a[i]!=a[n-i-1])
			{
				return 0;
			}
		}
		return 1;
	}
}
int same(char a[],int n)
{
	for(int i=1;i<n;i++)
	{
		if(a[i]!=a[i-1])
		{
			return 0;
		}
	}
	return 1;
}
int main()
{
	char str[20];
	scanf("%s",str);
	int n=strlen(str),count=0;
	if(n==1)
	{
		printf("0");
		return 0;
	}
	else if(same(str,strlen(str))==1)
	{
		printf("%d",n/2);
		return 0;
	}
	for(int i=1;i<n;i++)
	{
		char a[i],b[n-i];
		for(int j=0;j<i;j++)
		{
			a[j]=str[j];
		}
		if(ispalin(a,i)!=1)
		{
			continue;
		}
		for(int j=0;j<n-i;j++)
		{
			b[j]=str[i+j];
		}
		if(ispalin(b,n-i)==1)
		{
			count++;
		}
	}
	printf("%d",count);
	return 0;
}
