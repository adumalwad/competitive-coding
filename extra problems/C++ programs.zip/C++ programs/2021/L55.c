#include<stdio.h>
int main()
{
	long long int n,k;
	scanf("%lld",&n);
	long int a=0,b=1,sum=a+b;
	while(sum < n)
	{
		if(sum>10)
		{
			int count=0,sum1=0;
			k=sum;
			while(k!=0)
			{
				count++;
				sum1+=(k%10);
				k/=10;
			}
			if(sum1%count==0)
			{
				printf("%lld\n",sum);
			}
		}
		a=b;
		b=sum;	
		sum=a+b;
	}
	
	return 0;
}
