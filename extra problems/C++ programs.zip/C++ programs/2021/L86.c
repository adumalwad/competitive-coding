/*#include<stdio.h>
#include<math.h>
int counts(int n,int c)
{
	if((n==2)||(n==3))
	{
		return 1;
	}
	else
	{
		for(int i=1;i<sqrt(n);i++)
		{
			if(n%i==0)
			{
				
				printf("%d %d %d\n",n,i,counts(n-i,c));
			}
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int c=0;
	c=counts(n,c);
	printf("%d",c);
	return 0;
}*/
#include <stdio.h>
#include<math.h>
int func(int n){
	if(n<=1)return n;
	int ans=0;
	for(int i=1;i<=sqrt(n);i++){
		if(n%i==0){
			ans+=func(n-i);
		}
	}
	return ans;
}

int main() {
	// your code goes here
	int n;
	scanf("%d",&n);
	int ans;
	if(n<=1)ans=n;
	else{
		ans=func(n);
	}
	printf("%d",ans);
	return 0;
}

