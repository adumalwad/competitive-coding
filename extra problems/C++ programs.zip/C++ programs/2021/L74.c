#include<stdio.h>
int main()
{
	int a[10],b[10],a1=0,a2=0,a3=0;
	char ch;
	for(int i=0;i<10;i++)
	{
		scanf("%c",&ch);
		a[i]=ch-'0';
	//	printf("%d ",a[i]);
		a1+=a[i]*a[i];
	}
	scanf("\n");
	for(int i=0;i<10;i++)
	{
		scanf("%c",&ch);
		b[i]=ch-'0';
		//printf("%d ",b[i]);
		a2+=b[i]*b[i];
	//	a2+=(ch-'0')*(ch-'0');
		a3+=b[i]*a[i];
	}
	float v=(float)a3/(a1*a2);
	//printf("%d %d %d %.2f",a1,a2,a3,v);
	if(v>=0.90)
	{
		printf("S");
	}
	else if((v>=0.80)&&(v<0.90))
	{
		printf("A");
	}
	else if((v>=0.70)&&(v<0.80))
	{
		printf("B");
	}
	else if((v>=0.60)&&(v<0.70))
	{
		printf("C");
	}
	else if((v>=0.50)&&(v<0.60))
	{
		printf("D");
	}
	else if(v<0.50)
	{
		printf("F");
	}
	return 0;
}
