#include<stdio.h>
int totla(int n)
{
	if(n<=3)
	{
		return 0;
	}
	else if(n==4)
	{
		return 1;
	}
	else
	{
		if(n%2==1)
		{
			return totla(n-1);
		}
		else
		{
			return ((n-2)/2)+totla(n-1);
		}
	}
	
}
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d",totla(n));
	return 0;
}
