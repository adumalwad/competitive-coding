#include<stdio.h>
#include<math.h>
int isprime(int n)
{
	if((n==0) || (n==1))
	{
		return 0;
	}
	else if(n==2)
	{
		return 1;
	}
	else
	{
		for(int i=2;i<=sqrt(n)+1;i++)
		{
			if(n%i==0)
			{
				return 0;
			}
		}
		return 1;
	}
}
int main()
{
	int q;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		int N,n1=0,x1=0,y1=0,c=0;
		scanf("%d",&N);
		if(N%2==1)
		{
			N--;
		}
		if(N%2==0)
		{
			for(int n=N;n>=2;n=n-2)
			{
				for(int x=n/2;x>=2;x--)
				{
					int y=n-x;
					if((isprime(x)==1) && (isprime(y)==1))
					{
					//	printf("n=%d x=%d y=%d\n",n,x,y);
						c++;
						if(x>x1)
						{
							x1=x;
							y1=y;
							n1=n;
						}
						else if(x1==x)
						{
							if(n>n1)
							{
								x1=x;
								y1=y;
								n1=n;
							}
						}
					}
				}
			}
			if(c==0)
			{
				printf("No Solution\n");
			}
			else
			{
				printf("%d = %d + %d\n",n1,x1,y1);
			}
		}
		
	}
	return 0;
}
