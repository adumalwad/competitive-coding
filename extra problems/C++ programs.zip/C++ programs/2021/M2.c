#include<stdio.h>
int main()
{
	int x,n;
	char ch1,ch;
	scanf("%d\n",&x);
	scanf("%c",&ch);
	float sum=ch-'0';
//	printf("%d %c %f\n",x,ch,sum);
	//return 0;
	while(ch!='?')
	{
		if((ch=='+') ||(ch=='-') || (ch=='*') || (ch=='/'))
		{
			ch1=ch;	
		}
		else
		{
			if((ch>='0') && (ch<='9'))
			{
				n=ch-'0';
			}
			else if(ch=='x')
			{
				n=x;
			}
			switch(ch1)
			{
				case '+':
				{
					sum+=n;
					break;
				}
				case '-':
				{
					sum-=n;
					break;
				}
				case '*':
				{
					sum*=n;
					break;
				}
				case '/':
				{
					sum/=n;
					break;
				}
			}
			
		}
		scanf("%c",&ch);
	}
	printf("%.2f",sum);
	return 0;
}
