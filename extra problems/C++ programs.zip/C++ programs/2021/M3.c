#include<stdio.h>
int print_freq(int a[],int b[],int n)
{
	int c[n],d[n],z=0;
	for(int i=0;i<n;i++)
	{
		if(b[i]==(-1))
		{
			continue;
		}
		else
		{
			//printf("%d \n",b[i]);
			b[z]=b[i];
			c[z]=1;
			//printf("%d %d\n",b[z],c[z]);
			for(int j=i+1;j<n;j++)
			{
				if(b[j]==b[i])
				{
					b[j]=-1;
					c[z]++;
				}
			}
			printf("%d %d\n",b[z],c[z]);
			d[z]=c[z];
			z++;	
		}
	}
	for(int i=0;i<z;i++)
	{
		for(int j=0;j<z;j++)
		{
			if(d[i]<d[j])
			{
				int swap=d[j];
				d[j]=d[i];
				d[i]=swap;
			}
		}
	}
	for(int i=0;i<z;i++)
	{
		//printf("%d ",d[i]);
		if(i==0)
		{
			for(int j=0;j<z;j++)
			{
				if(c[j]==d[i])
				{
					printf("%d ",b[j]);
				}
			}	
		}
		else
		{
			if(d[i]!=d[i-1])
			{
				for(int j=0;j<z;j++)
				{
					if(c[j]==d[i])
					{
						printf("%d ",b[j]);
					}
				}	
			}
		}
		
	}
	
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	print_freq(a,b,n);
	return 0;
}
