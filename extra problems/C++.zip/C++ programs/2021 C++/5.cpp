#include<iostream>
using namespace std;
int main()
{
//	cout <<(1+2+3)-((-5)+10+1);
//	cout<< (float)((-1)+(-9)+5)/((-6)+7+(-8));
//	cout << "\"ESC\"-\'101\'";
//	cout << ((float)(1+4)/(3+7))+1.75;
//	cout << 10+20+30;
//	cout << "\\ is escape char\n\\n is new line\n\' is single quote\n\" is double quote";
	return 0;
}
