#include<iostream>
using namespace std;
//template <class na>         // passing two data type of same type
template <class na1,class na2>
/*na sum1(na a,na b)
{
	return a+b;
}*/
na2 sum2(na1 a,na2 b)
{
	return a+b;
}
int main()
{
	int a=1,b=2;
	float c=1.09,d=2.09;
	
	/*
	cout << sum1(a,b)<< endl;
	//cout << sum1(a,c);      // error (as a&c are fo diff type)
	cout << sum1(a,(int)c)<< endl;
	cout << sum1(c,d)<<endl; 
	*/
	cout << sum2(a,c);
	return 0;
}

