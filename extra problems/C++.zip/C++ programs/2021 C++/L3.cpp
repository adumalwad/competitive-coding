#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	char ch;
	int d;
	cin >> ch >>d;
	//cout << ch << " "<< d;
	cout << ch << " " << (int)ch << " " << (char)(ch+2) << " " << (int)(ch+2) <<"\n" << (ch <'Z');
	return 0;
}

/*#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int s,h,m;
	cin >> s;
	h=s/3600;
	s%=3600;
	m=s/60;
	s%=60;
	cout << h <<" Hours, "<< m << " Minutes, "<<s <<" Seconds";
	return 0;
}*/
/*#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int x1,y1,x2,y2;
	cin >> x1 >> y1 >> x2 >> y2;
	printf("%.3f",sqrt(pow(x1-x2,2)+pow(y1-y2,2)));
	return 0;
}*/
/*#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int s;
	cin >> s;
	printf("%.3f %d",(sqrt(3)/4)*s*s,(int)((sqrt(3)/4)*s*s));
//	cout << (sqrt(3)/4)*s*s;
	return 0;
}*/

