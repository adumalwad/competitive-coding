#include<iostream>
using namespace std;
class bc{
	public:
		bc(int p,int q,int r,string name)
		{
			a=p;
			b=q;
			c=r;
			str=name;
		}
		void display()
		{
			printf("%d %d %d ",a,b,c);
			cout << str;
		}
	private:
		int a,b,c;
		string str;
	
};
int main()
{
	bc bo(1,2,3,"Hello World!");
	bo.display();
	return 0;
}

