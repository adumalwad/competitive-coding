#include<iostream>
using namespace std;
void print_val(int a)
{
	cout << a << endl;
}
void print_val(float a)
{
	cout << a << endl;
}
int main()
{
	print_val(1);
	print_val((float)1.01);
	return 0;
}

