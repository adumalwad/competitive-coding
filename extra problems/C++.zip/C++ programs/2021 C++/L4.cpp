#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int x1,y1,r1,x2,y2,r2;
	cin >> x1 >> y1>> r1 >> x2 >> y2 >> r2;
	float dist=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	if(dist>(r1+r2))
	{
		cout << "far";
	}
	else if(dist<abs(r1-r2))
	{
		cout << "encloses";
	}
	else if((dist==(r1+r2))||(dist==abs(r1-r2)))
	{
		cout << "touches";
	}
	else
	{
		cout << "intersects";
	}
	return 0;
}

