#include<iostream>
using namespace std;

void reverse_arr(int *v,int size)
{
	int *f=v,*l=v+size-1;
	while(f<l)
	{
		int p=*f;
		*f=*l;
		*l=p;
		f++;
		l--;
	}
}
int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i=0;i<n;i++)
	{
		cin >> a[i];
	}
	for(int i=0;i<n;i++)
	{
		cout << a[i] << " ";
	}
	cout << endl;
	
	reverse_arr(a,n);
	for(int i=0;i<n;i++)
	{
		cout << a[i] <<" ";
	}
	return 0;
}

