#include<iostream>
#include<string>
#include<cstdlib>
using namespace std;
int* print_point(int *ptr1)
{
	int sum=*ptr1+5;
	cout << "function output is: " << *ptr1 << endl;
	return &sum;
}
int main()
{
	int n;
	int *ptr;
	ptr=&n;
	cin >> n;
	cout << *ptr << endl;
	*ptr=4;
	cout << n << endl;
	cout<< "Value returned from function is : " << *print_point(&n)<< endl;
	return 0;
}

