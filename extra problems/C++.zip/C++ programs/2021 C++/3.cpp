#include<iostream>
using namespace std;

int main()
{
	int a;
	float b;
	cin >> a >> b;
	cout << a << " "<< b <<"\n";
	cout << a/b;
	return 0;
}
