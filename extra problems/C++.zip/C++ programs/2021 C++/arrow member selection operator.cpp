#include<iostream>
#include<string>
using namespace std;
class bc{
	public:
		bc(int a,int b,int c)
		{
			p=a;
			q=b;
			r=c;
		}
	private:
		int p,q,r;
		string strl;
};
int main()
{
	return 0;
}

