#include<iostream>
using namespace std;
void print_vol(int a=10,int b=11,int c=12,int d=13)
{
	printf("%d %d %d %d\n",a,b,c,d);
}
int main()
{
	print_vol(1,2,3,4);
	print_vol(1,2,3);
	print_vol(1,2);
	print_vol(1);
	print_vol();
	return 0;
}

