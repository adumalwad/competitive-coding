#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	srand(time(0));
	for(int i=0;i<10;i++)
	{
		cout << "Time is : " <<time(0) <<" random value: ";
		cout << 1+(rand()%100) << endl;
	}
	return 0;
}

