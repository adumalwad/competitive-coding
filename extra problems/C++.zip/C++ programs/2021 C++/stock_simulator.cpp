#include<iostream>

using namespace std;
int main()
{
	int n,i=0;
	float p=1000,r=1.01;
	cin >> n;
	while(i<n)
	{
		p+=r*p;
		cout << "Day " << i << " amount is: "<<p<< endl;  
		i++;
	}
	return 0;
}

