#include<iostream>
#include<string>
#include<cstdlib>
using namespace std;
int main()
{
	
	return 0;
}

