#include<iostream>
#include<vector>
#include<algorithm>
#define all(v) v.begin(),v.end()
using namespace std;
int main()
{
	int n;
	vector<int>v;
	cin >> n;
	for(int i=0;i<n;i++)
	{
		v.push_back(i);
	}
	
	/*
	cout << "Vector \"v\"size is: " << v.size()<<endl;
	for(int i=0;i<v.size();i++)
	{
		cout << v.at(i) <<" ";
	}
	cout << endl;
	*/
	
	/*
	vector<int> v1(10),v2(n,15);
	cout << "Vector \"v2\"size is: " << v2.size()<<endl;
	for(int i=0;i<v1.size();i++)
	{
		cout << v1.at(i) <<" ";
	}
	*/
	
	/*
	cout << "Vector \"v2\"size is: " << v2.size()<<endl;
	for(int i=0;i<v2.size();i++)
	{
		cout << v2.at(i) <<" ";
	}
	cout << endl;
	*/
	
	
	/*vector<int> v3;
	v3=v;
	for(int i=0;i<v3.size();i++)
	{
		cout << v3.at(i) <<" ";
	}
	cout << end;
	*/
	
	/*
	vector <int> v4(v);
	for(int i=0;i<v4.size();i++)
	{
		//cout << v4.at(i) <<" ";
		cout << v4[i] << " ";
	}
	*/
	
	/*vector<int> v5(v.begin()+2,v.begin()+35);
	for(int i=0;i<v5.size();i++)
	{
		cout << v5.at(i) << " ";
	}
	cout << endl;*/
	
	/*
	int k=0,r,c;
	cin >> r >> c;
	vector< vector<int> >mat(r,vector<int >(c,-1));
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			mat[i][j]=k;
			k++;
		}
	}
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			cout << mat[i][j] << " ";
		}
		cout << endl;
	}
	*/
	
	/*
	int k=1,r,c;
	cin >> r;
	
	vector< vector<int> > mat1(r);
	for(int i=0;i<r;i++)
	{
		cin >> c;
		mat1[i] = vector<int>(c);
		for(int j=0;j<c;j++)
		{
			mat1[i][j]=k;
			k++;
		}
	}
	for(int i=0;i<mat1.size();i++)
	{
		for(int j=0;j<mat1[i].size();j++)
		{
			cout << mat1[i][j] << " ";
		}
		cout << endl;
	}
	*/
	/*
	cout << find(v.begin(),v.end(),4)-v.begin() << endl;
	cout << find(all(v),4)-v.begin()<< endl;
	*/
	
	return 0;
}

