#include<iostream>
using namespace std;
int main()
{
	int n;
	cin >> n;
	if((n>=1)&&(n<=5))
	{
		cout << "Week Day";
	}
	else if((n==6)||(n==7))
	{
		cout << "Weekend";
	}
	else
	{
		cout << "Please enter a valid day";
	}
	/*switch(n)
	{
		case 1:
		{
			cout << "Week Day";
			break;
		}
		case 2:
		{
			cout << "Week Day";
			break;
		}
		case 3:
		{
			cout << "Week Day";
			break;
		}
		case 4:
		{
			cout << "Week Day";
			break;
		}
		case 5:
		{
			cout << "Week Day";
			break;
		}
		case 6:
		{
			cout << "Weekend";
			break;
		}
		case 7:
		{
			cout << "Weekend";
			break;
		}
		default:
		{
			cout << "Plase enter a valid day";
			break;
		}
	}*/
	return 0;
}
