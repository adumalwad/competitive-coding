#include<iostream>
#include<cmath>
#include<string>

using namespace std;
class cn{
	public:
		void msgprint()
		{
			cout << "This is cool!!\n";
		}
		int sum1(int a,int b)
		{
			return a+b;
		}
		void set_var(string x)
		{
			str=x;
		}
		string get_str()
		{
			return str;
		}
	/*	void str_print(string str1)
		{
			cout << str1;
		}*/
	private:
		int a,b,c;
		string str;
};
int main()
{
	cn co;
	int a,b;
	
	/*co.msgprint();
	cin >> a >> b;
	cout << co.sum1(a,b)<<endl;
	co.str_print("This is a string :)"); */
	
	co.set_var("Hello World!");
	cout << co.get_str()<< endl;
	return 0;
}
