#include<iostream>
using namespace std;

int main()
{
	int a=7,b=3;
	printf("%.10f\n",(float)a/b);
	cout << (float)a/b;
	return 0;
}
