#include<iostream>
#include "bc2.h"
using namespace std;

bc2::bc2()
{
	cout << "This is a constructor" << endl;
}

bc2::~bc2()
{
	cout << "This is a deconstructor" << endl;
}
