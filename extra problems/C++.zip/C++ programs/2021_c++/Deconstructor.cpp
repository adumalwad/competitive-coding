#include<iostream>
#include "bc2.h"
using namespace std;
int main()
{
	bc2 bo2;
	cout << "This is a main()"<< endl;
	return 0;
}
