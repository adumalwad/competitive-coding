#ifndef BC2_H
#define BC2_H

class bc2
{
	public:
		bc2();
		~bc2();
	protected:
};

#endif
