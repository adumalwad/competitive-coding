#include<stdio.h>
int main()
{
	int m,n,sum=0;
	scanf("%d %d\n",&m,&n);
	int a[m+n],b[m],c[n];
	for(int i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
		a[i]=b[i];
		sum+=b[i];
	}
	for(int i=0;i<n;i++)
	{
		scanf("%d",&c[i]);
		a[i+m]=c[i];
		sum+=c[i];
	}
	for(int i=0;i<m+n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n%.2f",(float) sum/(m+n));
	return 0;
}
