#include<stdio.h>
#include<math.h>
int countd1(int n)
{
	int k=0;
	while(n!=0)
	{
		k++;
		n/=10;
	}
	return k;
}
int rev(int n,int k)
{
	int sum=0;
	while(n!=0)
	{
		sum+=(n%10)*pow(10,k-1);
		k--;
		n/=10;
	}
	return sum;
}
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int a1=countd1(a),b1=countd1(b);
	int x=rev(a,a1),y=rev(b,b1);
//	printf("%d %d",x,y);
	if((x%2==0) && (y%2==0))
	{
		printf("%d",x+y);
	}
	else if(((x%2==0) && (y%2==1)) || ((x%2==1) && (y%2==0)))
	{
		printf("%d",a+b);
	}
	else
	{
		printf("%d",a*b);
	}
	return 0;
}
