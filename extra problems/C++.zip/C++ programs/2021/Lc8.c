#include<stdio.h>
#include<stdlib.h>
int mergearr(int* a,int *b,int *c,int x,int y)
{
	int i=0,j=0,k=0;
	while((i<x)&&(j<y))
	{
		if(a[i]==b[j])
		{
			c[k]=a[i];
			i++;
			j++;
			k++;
		}
		else if(a[i]<b[j])
		{
			c[k]=a[i];
			i++;
			k++;
		}
		else
		{
			c[k]=b[j];
			j++;
			k++;
		}
	}
	if(i==x)
	{
		while(j!=y)
		{
			c[k]=b[j];
			j++;
			k++;
		}
	}
	else if(j==y)
	{
		while(i!=x)
		{
			c[k]=a[i];
			i++;
			k++;
		}
	}
	return k;
}
int main()
{
	int n,m,t,x,y;
	scanf("%d",&n);
	int *a,*b,*c;
	for(int j=0;j<n;j++)
	{
		scanf("%d",&m);
		if(j==0)
		{
			x=m;
			a=(int*)malloc(m*sizeof(int));
			for(int i=0;i<m;i++)
			{
				scanf("%d",a+i);
			}
		}
		else if(j==1)
		{
			b=(int*)malloc(m*sizeof(int));
			c=(int*)malloc((x+m)*sizeof(int));
			for(int i=0;i<m;i++)
			{
				scanf("%d",b+i);
			}
			t=mergearr(a,b,c,x,m);
			//c=(int *)realloc(c,t*sizeof(int));
			a=(int *)realloc(a,t*sizeof(int));
			for(int i=0;i<t;i++)
			{
				a[i]=c[i];
			//	printf("%d ",a[i]);
			}
			free(c);
		}
		else
		{
			b=(int*)malloc(m*sizeof(int));
			c=(int*)malloc((t+m)*sizeof(int));
			for(int i=0;i<m;i++)
			{
				scanf("%d",b+i);
			}
			t=mergearr(a,b,c,t,m);
			a=(int *)realloc(a,t*sizeof(int));
			for(int i=0;i<t;i++)
			{
				a[i]=c[i];
				//printf("%d ",a[i]);
			}
			free(c);
		}
	}
	for(int i=0;i<t;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
