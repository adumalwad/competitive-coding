#include<stdio.h>
int main()
{
	long int n,m,fact=1,i=1,count=0;
	scanf("%ld %ld",&n,&m);
	while(fact<=m)
	{
		fact=fact*i;
		if((fact>=n) && (fact<=m))
		{
			count++;
		}
		i++;
	}
	printf("%d",count);
	return 0;
}
