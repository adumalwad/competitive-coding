#include<stdio.h>                      //recursive algorithm
int find_max(int a[],int s,int n)
{
	int max=a[s],j=s;
	for(int i=s+1;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			j=i;
		}	
	}
	return j;
}
void swap(int a[],int i,int j)
{
	int s=a[i];
	a[i]=a[j];
	a[j]=s;
}
void selecs(int a[],int s,int n)
{
	if(s==n-1)
	{
		return;
	}
	int i=find_max(a,s,n);
	swap(a,i,s);
	selecs(a,s+1,n);
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	selecs(a,0,n);
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
/*#include<stdio.h>                          //iterative algo
int main()
{
	int n,k=0,s;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	for(int i=0;i<n-1;i++)
	{
		int max=a[i];
		k=i;
		for(int j=i;j<n;j++)
		{
			if(a[j]>max)
			{
				max=a[j];
				k=j;
			}
		}
		s=a[i];
		a[i]=a[k];
		a[k]=s;
	}
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}*/
