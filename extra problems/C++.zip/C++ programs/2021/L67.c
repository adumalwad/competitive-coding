#include<stdio.h>
int cd(int n)
{
	int k,max=0;
	while(n!=0)
	{
		k=n%10;
		if(k>max)
		{
			max=k;
		}
		n/=10;
	}
	return max;
}
int main()
{
	int q,x,y;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%d %d",&x,&y);
		int nx=cd(x),ny=cd(y);
		if(nx>=ny)
		{
			printf("%d\n",x);	
		}
		else
		{
			printf("%d\n",y);
		}
	}
}
