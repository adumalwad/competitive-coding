#include<stdio.h>
#include<stdlib.h>
void swap1(int* a,int x,int y)
{
	int s=*(a+x);
	*(a+x)=*(a+y);
	*(a+y)=s;
}
int main()
{
	int t,n,m,x,y;
	scanf("%d",&t);
	for(int i=0;i<t;i++)
	{
		int *a;
		scanf("%d %d",&n,&m);
		a=(int *)malloc(n*sizeof(int));
		for(int p=0;p<n;p++)
		{
			scanf("%d",a+p);
		}
		for(int j=0;j<m;j++)
		{
			scanf("%d %d",&x,&y);
			swap1(a,x,y);
		}
		for(int j=0;j<n;j++)
		{
			printf("%d ",*(a+j));
		}
		printf("\n");
	}
	return 0;
}
