#include<stdio.h>
int main()
{
	int a,b,n,n1,k=0,v=5;
	scanf("%d %d",&a,&b);
	for(int j=0;j<a;j++)
	{
		int c=0;
		printf("xx=%d\n",k);
		for(int i=0;i<b;i++)
		{
			scanf("%d",&n);
			if(j==0)
			{
				if(i==0)
				{
					n1=n;	
				}
				else
				{
					if(c!=(-1))
					{
						if((n1==0) && (n==1))
						{
							printf("%d\n",i-1);
							c=-1;
							k=i-1;
							v=j;
						}
						if((n1==0) && (n==0) && (i==b-1))
						{
							printf("%d\n",i);
							k=i;
							v=j;
						}	
					}
					
				}
			}
			else
			{
				if((i>=k) && (c!=(-1)))
				{
					if((n1==0) && (n==1))
					{
						if(v==j-1)
						{
							printf("Angry Mouse");
							return 0;
						}
						else
						{
							c=-1;
							printf("%d\n",i-1);
							k=i-1;
							v=j;
						}
					
					}
					if((n1==0) && (n==0))
					{
						v=j;
						if(i==b-1)
						{
							c=-1;
							printf("%d\n",i);
							k=i;
						
						}
					}
				}
			}
		}
	}
	return 0;
}
