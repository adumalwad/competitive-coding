#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<int>v(n);
    for(int i=0;i<n;i++)
    {
        cin >> v.at(i);
    }
    sort(v.begin(),v.end());
    int x=v.size();
    while(x>0)
    {
        cout << v.size()<< endl;
        int i=0;
        while(v[i]==v[0])
        {
            i++;
        }
        x=x-i;
        v.erase(v.begin(),v.begin()+i);
    }
    return 0;
}
