#include<stdio.h> //insert element in linked list at specified index
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node* next;
}no;
void display(no* a)
{
	no* cur=a;
	while(cur!=NULL)
	{
		printf("%d ",cur->data);
		cur=cur->next;
	}
	printf("\n");
}
no* make_node(int v)
{
	no* tmp=(no*)malloc(sizeof(no));
	tmp->data=v;
	return tmp;
}
no* insert_element(no* a,int v)
{
	no* tmp=(no*)malloc(sizeof(no));
	tmp=make_node(v);
	tmp->next=NULL;
	if(a!=NULL)
	{
		tmp->next=a->next;
		a->next=tmp;
		return a;	
	}
	else
	{
		return tmp;
	}
}
int main()
{
	int n,v,k;
	no* a=NULL;
	scanf("%d",&n);
	a=(no*)malloc(n*sizeof(no));
	for(int i=0;i<n;i++)
	{
		scanf("%d",&v);
		a[i].data=v;
		if(i==n-1)
		{
			a[i].next=NULL;
		}
		else
		{
			a[i].next=a+i+1;
		}
	}
	display(a);
	scanf("%d %d",&v,&k);
	insert_element(a+k-1,v);	 // to insert element at beginning
	display(a);
	return 0;
}


/*#include<stdio.h> //insert element in linked list at front
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node* next;
}no;
void display(no* a)
{
	no* cur=a;
	while(cur!=NULL)
	{
		printf("%d ",cur->data);
		cur=cur->next;
	}
	printf("\n");
}
no* make_node(int v)
{
	no* tmp=(no*)malloc(sizeof(no));
	tmp->data=v;
	return tmp;
}
no* insert_element(no* a,int v)
{
	no* tmp=(no*)malloc(sizeof(no));
	tmp=make_node(v);
	tmp->next=a;
	a=tmp;
	return a;
}
int main()
{
	int n,v,k;
	no* a;
	scanf("%d",&n);
	a=(no*)malloc(n*sizeof(no));
	for(int i=0;i<n;i++)
	{
		scanf("%d",&v);
		a[i].data=v;
		if(i==n-1)
		{
			a[i].next=NULL;
		}
		else
		{
			a[i].next=a+i+1;
		}
	}
	display(a);
	scanf("%d",&v);
	// to insert element at beginning
	a=insert_element(a,v);	
	display(a);
	return 0;
}*/
