#include<stdio.h>
#include<math.h>
int isdigit1(int sum,int k,int d,int ins)
{
	while(ins!=0)
	{
		if((sum/((int)pow(10,k)))==d)
		{
			return 1;
		}
		sum%=((int)pow(10,k));
		ins-=1;
		k=k-1;
	}
	return 0;
}
int print_num(int a[],int n,int sum,int ins,int k,int t)
{
	if(k==0)
	{
		printf("%d\n",sum);
	}
	else
	{
		for(int i=0;i<n;i++)
		{
			if(isdigit1((int)sum,t,a[i],ins)!=1)
			{
				print_num(a,n,sum+a[i]*((int)pow(10,k-1)),ins+1,k-1,t);	
			}
		}
	}
}
int main()
{
	int n,k,sum=0;
	scanf("%d %d",&n,&k);
	int a[n];
	for(int i=0;i<n;i++)
	{
		a[i]=i;
		printf("%d\n",a[i]);
	}
	for(int i=2;i<=k;i++)
	{
		for(int j=1;j<n;j++)
		{
			sum=a[j]*(int)pow(10,i-1);
			print_num(a,n,sum,1,i-1,i-1);
			
		}
	}
	return 0;
}
