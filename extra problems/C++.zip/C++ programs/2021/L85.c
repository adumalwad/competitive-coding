#include<stdio.h>
int countv(int n,int count)
{
	if(n==1)
	{
		printf("%d ",n);
		count++;
		return count;
	}
	else if(n%2==1)
	{
		printf("%d ",n);
		countv(3*n+1,count+1);
	}
	else if(n%2==0)
	{
		printf("%d ",n);
		countv(n/2,count+1);
	}
	
}
int main()
{
	int n;
	scanf("%d",&n);
//	printf("%d ",n);
	printf("\n%d",countv(n,0));
	return 0;
}
