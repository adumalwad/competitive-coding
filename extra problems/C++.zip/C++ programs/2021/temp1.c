#include<stdio.h>
#include<stdlib.h>
int main()
{
	int s,q,**a,*c;
	scanf("%d %d",&s,&q);
	a=(int **)malloc((sizeof(int *))*s);
	c=(int *)malloc((sizeof(int))*s);
	for(int i=0;i<s;i++)
	{
		a[i]=(int *)malloc(sizeof(int));
		c[i]=0;
	}
	for(int i=0;i<q;i++)
	{
		int x,y,z,tmp;
		scanf("%d",&z);
		if(z==1)
		{
			scanf("%d %d",&x,&y);
			if(c[x]>=1)
			{
				a[x]=(int *)realloc(a[x],(c[x]+1));
			}
			tmp=c[x];
			a[x][tmp]=y;
			c[x]++;
			//printf("x=%d y=%d %d c=%d\n",x,y,a[x][tmp],c[x]);
		}
		else if(z==2)
		{
			scanf("%d %d",&x,&y);
			printf("%d\n",x,y,a[x][y]);
		}
		if(z==3)
		{
			scanf("%d",&x);
			printf("%d\n",c[x]);
		}
	}
	return 0;
}
