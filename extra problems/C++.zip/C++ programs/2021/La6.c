#include<stdio.h>
#include<string.h>
int main()
{
	int n,c=0;
	scanf("%d",&n);
	char a[n][20],ch[20];
	for(int i=0;i<n;i++)
	{
		scanf("%s[^\n]",a[i]);
	}
	scanf("%s",ch);
	for(int i=0;i<n;i++)
	{
		//printf("%s ",a[i]);
		if(strcasecmp(ch,a[i])>0)
		{
		//	printf("%s\n",a[i]);
			c++;
		}
	}
	printf("%d",c+1);
	return 0;
}
