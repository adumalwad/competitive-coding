#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i]<a[j])
			{
				int s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
	if(n%2==0)
	{
		printf("%.1f",(float)(a[(n/2)-1]+a[n/2])/2);
	}
	else
	{
		printf("%.1f",(float)(a[n/2]));
	}
	return 0;
}
