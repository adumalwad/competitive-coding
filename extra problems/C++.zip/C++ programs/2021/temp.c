#include<stdio.h>
#include<string.h>
int main()
{
	int n;
	char str[100];
	//gets(str);
	int a=2;
	printf("%d",++a + ++a);
/*	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		if(i==n-1)
		{
			for(int j=0;j<2*n+1;j++)
			{
				if( (j>=(n-i)) && (j<=n+i))
				{
					printf("*");
				}
				else
				{
					printf(" ");
				}
			}
			continue;
		}
		for(int j=0;j<2*n+1;j++)
		{
			if((j==(n+i))||(j==(n-i)))
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
	}*/
	return 0;
}
/*#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			printf(" ");
		}
		for(int j=0;j<6;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	return 0;
}*/
