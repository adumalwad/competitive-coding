#include<stdio.h>
void print_pos(char a[],int k,char b[],int p,int n);
void print_pos1(char a[],int k,char b[],int p,int n);
// If this code is not runnig,copy it into new file and try to run
int main()
{
	int n;
	scanf("%d",&n);
	char a[2]={'0','1'},b[n];
	if(n==1)
	{
		printf("0\n1");
	}
	else
	{
		for(int i=0;i<2;i++)
		{
			if(i==0)
			{
				b[0]=a[0];
				print_pos(a,2,b,1,n);	
			}
			if(i==1)
			{
				b[0]=a[1];
				print_pos1(a,2,b,1,n);
			}	
		}
		
	}
}
void print_pos(char a[],int k,char b[],int p,int n)
{
	if(p==n)
	{
		b[p]='\0';
		printf("%s\n",b);
	}
	else
	{
		for(int i=0;i<k;i++)
		{
			b[p]=a[i];
			if(i==0)
			{
				print_pos(a,k,b,p+1,n);	
			}
			if(i==1)
			{
				print_pos1(a,k,b,p+1,n);
			}
			
		}
	}
}
void print_pos1(char a[],int k,char b[],int p,int n)
{
	if(p==n)
	{
		b[p]='\0';
		printf("%s\n",b);
	}
	else
	{
		for(int i=k-1;i>=0;i--)
		{
			b[p]=a[i];
			if(i==0)
			{
				print_pos1(a,k,b,p+1,n);	
			}
			if(i==1)
			{
				print_pos(a,k,b,p+1,n);
			}
			//print_pos1(a,k,b,p+1,n);
		}
	}
}
