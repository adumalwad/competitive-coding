#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,m,i=0,j=0;
	char *a,*b;
	scanf("%d %d\n",&n,&m);
	a=(char*)malloc(n*sizeof(char));
	b=(char*)malloc(m*sizeof(char));
	scanf("%s %s",a,b);
	//printf("%s %s\n",a,b);
	while((i<n)&&(j<m))
	{
		if(a[i]==b[j])
		{
			//printf("%c\n",a[i]);
			i++;
		}
		else
		{
			j++;
		}
	}
	if(i==n)
	{
		printf("YES");
	}
	else
	{
		printf("NO");
	}
	return 0;
}
