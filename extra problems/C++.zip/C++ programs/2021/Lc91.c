#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,m,**a,r=1,sum=0;
	scanf("%d",&n);
	a=(int**)malloc((sizeof(int *)*n));
	for(int i=0;i<n;i++)
	{
		scanf("%d",&m);
		a[i]=(int*)malloc((sizeof(int)*m));
		for(int j=0;j<m;j++)
		{
			scanf("%d",(*(a+i)+j));
			sum+=(*(*(a+i)+j))*r*r;
			r++;
			
		}
	}
	printf("%d",sum);
	return 0;
}
