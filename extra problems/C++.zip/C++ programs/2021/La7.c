#include<stdio.h>
#include<string.h>
int main()
{
	int n;
	scanf("%d",&n);
	char a[n][20],ch[20];
	int j=0,mx=0,c;
	for(int i=0;i<n;i++)
	{
		scanf("%s[^\n]",a[i]);
	}
/*	for(int i=0;i<n;i++)
	{
		printf("%s ",a[i]);
	}
	printf("\n");*/
	for(int i=0;i<n;i++)
	{
		if(strcasecmp(a[i],"0")==0)
		{
			continue;
		}
		else
		{
		//	printf("%s ",a[i]);
			c=1;
			for(int j=i+1;j<n;j++)
			{
			
				if(strcasecmp(a[i],a[j])==0)
				{
					strcpy(a[j],"0");
					c++;
				}
			}
			//printf("%s %d\n",a[i],c);
			if(c>mx)
			{
				mx=c;
				strcpy(ch,a[i]);
			}
			else if((c==mx) &&(strcasecmp(ch,a[i])>0))
			{
				strcpy(ch,a[i]);
			}
		}
	}
	printf("%s",ch);
	return 0;
}
