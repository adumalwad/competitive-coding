#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node* next;
}na;
na* make_node(int val)
{
	na* tmp;
	tmp=(na*)malloc(sizeof(na));
	tmp->data=val;
	return tmp;
}
na* insert_front(int val,na *head) 
{
	na *newnode= make_node(val); 
	newnode->next = head;
	head = newnode; 
	return head;
}

void display(na* a)
{
	na* cur=a;
	while(a!=NULL)
	{
		printf("%d ",a->data);
		a=a->next;
	}
	printf("\n");
}
int main()
{
	int n;
	na* a;
	scanf("%d",&n);
	a=(na*)malloc(sizeof(na)*(n+1));
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i].data);
		if(i==n-1)
		{
			a[i].next=NULL;
		}
		else
		{
			a[i].next=a+i+1;	
		}
		
	}
	a=insert_front(20,a);
	display(a);
	return 0;
}

