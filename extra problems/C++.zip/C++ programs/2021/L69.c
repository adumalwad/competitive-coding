#include<stdio.h>
int ispyth(int a,int b,int c)
{
	if((a>=b) && (a>=c) && (a*a==b*b+c*c))
	{
		return 1;
	}
	else if((b>=a) && (b>=c) && (b*b==a*a+c*c))
	{
		return 1;
	}
	else if((c>=b) && (c>=a) && (c*c==b*b+a*a))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	int q,a,b,c;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%d %d %d",&a,&b,&c);
		if(ispyth(a,b,c)==1)
		{
			printf("Yes\n");
		}
		else
		{
			printf("No\n");
		}
	}
	return 0;
}
