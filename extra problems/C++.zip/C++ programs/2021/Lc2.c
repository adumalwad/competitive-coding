#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,m,**a,c=0,sum=0;
	scanf("%d",&n);
	a=(int**)malloc(n*sizeof(int *));
	for(int i=0;i<n;i++)
	{
		scanf("%d",&m);
		c+=m;
		a[i]=(int *)malloc(m*sizeof(int));
		for(int j=0;j<m;j++)
		{
			scanf("%d",(*(a+i)+j));
			//printf("%d ",*(*(a+i)+j));
			sum+=*(*(a+i)+j);
		}
		//printf("\n");
	}
	printf("%d",sum/c);
	return 0;
}
