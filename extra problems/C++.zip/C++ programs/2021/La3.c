#include<stdio.h>
int s(int a[],int str,int las,int k)
{
	/*for(int i=str;i<=las;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");*/
	if(str>las)
	{
		printf("NOT FOUND");
		return 0;
	}
	int mid=(str+las)/2;
	if(a[mid]==k)
	{
		printf("%d",mid);
		return 1;
	}
	else if(k>a[mid])
	{
		s(a,mid+1,las,k);
	}
	else if(k<a[mid])
	{
		s(a,str,mid-1,k);
	}
	
}
int main()
{
	int n,k,maxi=0,mini=0;
	scanf("%d",&n);
	int a[n];
	scanf("%d",&a[0]);
	int max=a[0],min=a[0];
	
	for(int i=1;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>max)
		{
			max=a[i];
			maxi=i;
		}
		else if(a[i]<min)
		{
			min=a[i];
			mini=i;
		}
	}
	scanf("%d",&k);
	//printf("%d %d %d %d\n",max,maxi,min,mini);
	if((k>max)||(k<min))
	{
		printf("NOT FOUND");
		return 0;
	}
	else
	{
		if((k>=a[0])&&(k<=max))
		{
			printf("l1\n");
			s(a,0,maxi,k);
			
		}
		else
		{
		//	printf("l2\n");
			s(a,mini,n-1,k);
		}
	}
	return 0;
}
