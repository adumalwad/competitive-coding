#include<stdio.h>
void merge(int a[],int s,int n)
{
	int tem[1000],i=s,j=s+(n/2);
	int lim_i=s+(n/2),lim_j=s+n;
	for(int x=0;x<n;x++)
	{
		if((i<lim_i)&&(j<lim_j))
		{
			if(a[i]<=a[j])
			{
				tem[x]=a[i];
				i++;
			}
			else
			{
				tem[x]=a[j];
				j++;
			}
		}
		else if(i==lim_i)
		{
			tem[x]=a[j];
			j++;
		}
		else
		{
			tem[x]=a[i];
			i++;
		}
	}
	for(int x=0;x<n;x++)
	{
		a[s+x]=tem[x];
	}
}
void merges(int a[],int s,int n)
{
	if(n>1)
	{
		int m=n/2;
		merges(a,s,m);
		merges(a,s+m,n-m);
		merge(a,s,n);
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	merges(a,0,n);
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
