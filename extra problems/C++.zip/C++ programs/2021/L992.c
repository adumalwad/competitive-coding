#include<stdio.h>
#include<string.h>
/*void sorts(char a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(a[i]>a[j])
			{
				char s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
}*/
void printstr(char a[],char b[],int s,int ins,int n,int len)
{
	//printf("ins=%d\n",ins);
	
	if(ins==len)
	{
		b[ins]='\0';
		printf("%s\n",b);
	}
	else
	{
		for(int j=s;j<n;j++)
		{
			//	printf("a[j]=%c j=%d ins=%d s=%d\n",a[j],j,ins);
				b[ins]=a[j];
				printstr(a,b,j+1,ins+1,n,len);	
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	char a[n],b[n];
	scanf("%s",a);
	//sorts(a,strlen(a));
	//printf("%s\n",a);
	for(int i=1;i<=n;i++)
	{
		if(i==1)
		{
			for(int j=0;j<n;j++)
			{
				printf("%c\n",a[j]);
			}
		}
		else
		{
			printstr(a,b,0,0,n,i);
		}
	}
	return 0;
}
