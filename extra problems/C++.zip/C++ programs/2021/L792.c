#include<stdio.h>
#include<math.h>
int main()
{
	int n;
	scanf("%d",&n);
	float a[5];
	int b[n];
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&b[j]);
		}
		int sum1=0,sum2=0;
		for(int x=0;x<n;x++)
		{
			for(int y=0;y<n;y++)
			{
				sum1+=abs(b[x]-b[y]);
				sum2+=b[y];
			}
		}
		printf("sum1=%d sum2=%d\n",sum1,sum2);
		a[i]=(float)sum1/(2*sum2);
	}
	float max=a[0];
	int p;
	for(int i=0;i<5;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			p=i+1;
		}
		printf("%.2f ",a[i]);
	}
	printf("\nThe unfairest tutor is tutor %d",p);
	return 0;
}
