#include<stdio.h>
#include<stdlib.h>
int is_valid(int** a,int i,int j,int n,int k,int r,int c)
{
	// for row check
	for(int p=0;p<n;p++)
	{
		if(a[i][p]==k)
		{
			return 0;
		}
	}
	for(int p=0;p<n;p++)
	{
		if(a[p][j]==k)
		{
			return 0;
		}
	}
	int x=i-i%r,y=j-j%c;
	for (int p = 0; p < r; p++)
	{
		for (int q = 0; q < c; q++)
		{
			if (a[p + x][q + y] == k)
			{
				return 0;		
			}
		}	
	}
	return 1;
}
int print_sudoku(int** a,int i,int j,int n,int row,int column)
{
	if((i==n-1)&&(j==n))
	{
		return 1;
	}
	else if(j==n)
	{
		i++;
		j=0;
	}
	if(a[i][j]>0)
	{
		return print_sudoku(a,i,j+1,n,row,column);
	}
	for(int k=1;k<=n;k++)
	{
		if(is_valid(a,i,j,n,k,row,column)==1)
		{
			a[i][j]=k;
			if(print_sudoku(a, i, j + 1,n,row,column)==1)
            {
            	return 1;	
			}
		}
		a[i][j] = 0;
	}
	return 0;	
}
int main()
{
	int n,r,c;
	scanf("%d %d %d",&n,&r,&c);

 	 int **a = (int **)malloc(n * sizeof(int *)); 
    for (int x=0; x<r; x++) 
         a[x] = (int *)malloc(n * sizeof(int)); 

	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	print_sudoku(a,0,0,n,r,c);
	return 0;
}
