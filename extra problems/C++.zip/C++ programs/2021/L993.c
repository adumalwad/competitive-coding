#include<stdio.h>
#include<string.h>
int ispower(int n)
{
	if(n==2)
	{
		return 1;
	}
	while(n!=2)
	{
		if(n%2==1)
		{
			return 0;
		}
		n/=2;
	}
	return 1;
}
void sort(char str[],int n)
{
	char s;
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(str[i]>str[j])
			{
				s=str[i];
				str[i]=str[j];
				str[j]=s;
			}
		}
	}
}
int main()
{
	char str[100];
	int k;
	scanf("%s\n",str);
	scanf("%d",&k);
	int n=strlen(str);
	//printf("%s %d",str,k);
	if(ispower(n)==1)
	{
		k/=2;
	}
	else
	{
		k*=2;
	}
	if(n-k<=0)
	{
		printf("-1");
	}
	else
	{
		sort(str,n);
		for(int i=0;i<(n-k);i++)
		{
			printf("%c",str[i]);
		}
	}
	return 0;
}
