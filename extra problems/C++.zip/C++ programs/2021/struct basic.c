/*#include<stdio.h>       //area of n rectangles comparison
#include<stdlib.h>
typedef struct point
{
	int x;
	int y;
}p1;
typedef struct retc
{
	p1 lb;
	p1 rt;
}r1;
p1* make_pt(int x,int y)
{
	
	p1* tmp=(p1*)malloc(sizeof(p1));
	tmp->x=x;
	tmp->y=y;
	return tmp;
}
void print_ar(r1* rk)
{
	int ar=(rk->rt.x - rk->lb.x)*(rk->rt.y-rk->lb.y);
	printf("%d\n",ar);
}
int main()
{
	int x,y;
	r1 *rec;
	rec=(r1*)malloc(3*sizeof(r1));
	for(int i=0;i<3;i++)
	{
		scanf("%d %d",&x,&y);
		rec[i].lb=*make_pt(x,y);
		//(rec+i)->lb= *make_pt(x,y);
		scanf("%d %d",&x,&y);
		rec[i].rt=*make_pt(x,y);
		//(rec+i)->rt= *make_pt(x,y);
		printf("%d %d %d %d\n",rec[i].lb.x,rec[i].lb.y,rec[i].rt.x,rec[i].rt.y);
	}
	for(int i=0;i<3;i++)
	{
		print_ar(rec+i);
	}
	return 0;
}*/



/*#include<stdio.h>  // rectangle imput
#include<stdlib.h>
typedef struct point
{
	int x;
	int y;
}p1;
typedef struct retc
{
	p1 lb;
	p1 rt;
}r1;
p1* make_pt(int x,int y)
{
	
	p1* tmp=(p1*)malloc(sizeof(p1));
	tmp->x=x;
	tmp->y=y;
	return tmp;
}
int main()
{
	int x,y;
	r1 rec;
	//rec=(r1*)malloc(sizeof(r1));
	scanf("%d %d",&x,&y);
	rec.lb= *make_pt(x,y);
	scanf("%d %d",&x,&y);
	rec.rt= *make_pt(x,y);
	printf("%d %d %d %d",rec.lb.x,rec.lb.y,rec.rt.x,rec.rt.y);
	return 0;
}*/

#include<stdio.h>        //structure array of n points
#include<stdlib.h>
typedef struct point
{
	int x;
	int y;
}p1;
p1* make_pt(int x,int y)
{
	
	p1* tmp=(p1*)malloc(sizeof(p1));
	tmp->x=x;
	tmp->y=y;
	return tmp;
}
int main()
{
	int x,y;
	p1* pt;
	pt=(p1*) malloc(3*sizeof(p1));
	for(int i=0;i<3;i++)
	{
		scanf("%d %d",&x,&y);
		//pt[i].x=x;
		//pt[i].y=y;
		pt[i] = *make_pt(x,y);
	//	printf("%d %d\n",pt[i].x,pt[i].y);	
	}
	for(int i=0;i<3;i++)
	{
		printf("%d %d\n",pt[i].x,pt[i].y);	
	}
	return 0;
}



/*#include<stdio.h>
#include<stdlib.h>
typedef struct point
{
	int x;
	int y;
}p1;
p1* make_pt(int x,int y)
{
	
	p1* tmp=(p1*)malloc(sizeof(p1));
	tmp->x=x;
	tmp->y=y;
	return tmp;
}
int main()
{
	int x,y;
	p1* pt;
	scanf("%d %d",&x,&y);
	pt=make_pt(x,y);
	printf("%d %d",pt->x,pt->y);
	return 0;
}*/
