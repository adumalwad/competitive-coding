#include<stdio.h>
void sort_str(char* a,int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if((*(a+i)>(*(a+j))))
			{
				char ch=*(a+i);
				*(a+i)=*(a+j);
				*(a+j)=ch;
			}
		}
	}	
}
int ischar1(char* b,char ch,int k)
{
	int i=0;
	while(i<k)
	{
		if(b[i]==ch)
		{
			return 1;
		}
		i++;
	}
	return 0;
}
void printp(char *a,char *b,int k,int n)
{
	if(k==n)
	{
		b[k]='\0';
		printf("%s\n",b);
	}
	else
	{
		for(int i=0;i<n;i++)
		{
			if(ischar1(b,a[i],k)!=1)
			{
				b[k]=a[i];
				printp(a,b,k+1,n);
			}
			
		}
	}
}
int main()
{
	int n;
	scanf("%d\n",&n);
	char a[n],b[n+1];
	scanf("%s",a);
	sort_str(a,n);
	
	//printf("%s",a);
	printp(a,b,0,n);
	return 0;
}
