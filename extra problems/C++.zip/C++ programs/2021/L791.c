#include<stdio.h>
#include<math.h>
int main()
{
	int n,sum=0;
	scanf("%d",&n);
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i]*a[i];
		printf("%d ",b[i]);
		sum+=b[i];
	}
	printf("\n%.2f",sqrt(sum));
	return 0;
}
