#include<stdio.h>
int matchs(int a[],int sa,int la,int b[],int sb,int lb,int c[])
{
	if(sa>=la)
	{
		return 0;
	}
	else if((sa<la)&&(sb==lb))
	{
		matchs(a,sa+1,la,b,sa+1,lb,c);
	}
	else if(a[sa]==b[sb])
	{
		printf("a[sa]=%d b[sb]=%d\n",a[sa],b[sb]);
		c[0]++;
		matchs(a,sa+1,la,b,sb+1,lb,c);
	}
	else
	{
		matchs(a,sa,la,b,sb+1,lb,c);
	}
}
int main()
{
	int n,m;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d",&m);
	int b[m],c[1];
	for(int i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
	}
	c[0]=0;
	matchs(a,0,n,b,0,m,c);
	printf("%d",c[0]);
//	printf("%d",matchs(a,0,n,b,0,m,c));
	return 0;
}
