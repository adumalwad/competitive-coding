#include<stdio.h>

void reverse_arr(int *v,int size)
{
	int *f=v,*l=v+size-1;
	while(f<l)
	{
		int p=*f;
		*f=*l;
		*l=p;
		f++;
		l--;
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
	
	reverse_arr(a,n);
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}

