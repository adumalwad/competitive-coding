#include<stdio.h>
#include<math.h>
#include<stdlib.h>
typedef struct point
{
	double x;
	double y;
}p1;
p1* make_pt(double x,double y)
{
	p1* tmp=(p1*)malloc(sizeof(p1));
	tmp->x=x;
	tmp->y=y;
	return tmp;
	
}
int main()
{
	int n;
	double x,y,max,min,area;
	p1 *p;
	scanf("%d",&n);
	p=(p1*) malloc(sizeof(p1)*n);
	for(int i=0;i<n;i++)
	{
		scanf("%lf %lf",&x,&y);
		*(p+i)=*make_pt(x,y);
		//printf("%lf %lf\n",(p+i)->x,(p+i)->y);
	}
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			for(int k=j+1;k<n;k++)
			{
			
				//printf("%lf %lf %lf %lf %lf %lf\n",(p+i)->x,(p+i)->y,(p+j)->x,(p+j)->y,(p+k)->x,(p+k)->y);
				area=((p+i)->x - p[j].x)*(p[j].y-p[k].y)-(p[i].y-p[j].y)*(p[j].x-p[k].x);
				if(area<0)
				{
					area=-area;
				}
			//	printf("area=%.5lf\n",area/2);
				if((i==0)&&(j==1)&&(k==2))
				{
					max=area;
					min=area;
				}
				else
				{
					if(area>max)
					{
						max=area;
					}
					else if(area<min)
					{
						min=area;	
					}
				}
			}
		}
	}
	printf("Max Area:%.5lf\nMin Area:%.5lf",max/2,min/2);
	return 0;
}
