#include<stdio.h>
#include<math.h>
int prime(int n)
{
	for(int i=2;i<=sqrt(n);i++)
	{
		if(n%i==0)
		{
			return 0;
		}
	}
	return 1;
}
int main()
{
	int n,c=1,p=2;
	scanf("%d",&n);
	if(n==1)
	{
		printf("%d",p);
		return 0;
	}
	int j=3;
	while(c!=n)
	{
		while(prime(j)==0)
		{
			//printf("%d\n",j);
			j++;	
		}
		p*=j;
		j++;
		c++;
	}
	printf("%d",p);
	return 0;	
}
