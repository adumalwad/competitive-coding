#include<stdio.h>
int gcd(int a,int b)
{
	int s;
	if(a%b==0)
	{
		return b;
	}
	else
	{
		gcd(b,a%b);
	}
}
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);  // Here a>b
	printf("%d\n",gcd(a,b));
	printf("%c",325);
	return 0;
}
