#include<stdio.h>
#include<stdlib.h>
void cpyarr(int* a,int* b,int n)
{
	for(int i=0;i<n;i++)
	{
		*(b+i)=*(a+i);
	}
}
int main()
{
	int n,m,*a,*b,s,f,k;
	scanf("%d %d",&n,&m);
	a=(int*)malloc(n*sizeof(int));
	b=(int*)malloc(n*sizeof(int));
	for(int i=0;i<n;i++)
	{
		scanf("%d",(a+i));
		*(b+i)=*(a+i);
	}
/*	for(int i=0;i<n;i++)
	{
		printf("%d %d\n",*(a+i),*(b+i));
	}*/
	for(int i=0;i<m;i++)
	{
		scanf("%d",&s);
		scanf("%d",&f);
		if(s==-1)
		{
			n=f;
			cpyarr(a,b,n);
		}
		else
		{
			*(a+s)=*(b+f);
			*(a+f)=*(b+s);
		}
	}
	for(int i=0;i<n;i++)
	{
		printf("%d ",*(a+i));
	}
	return 0;
}
