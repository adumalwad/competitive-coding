#include<stdio.h>
int read(char s[],int n)
{
	int i=0;
	char ch;
	ch=getchar();
	while((ch!='\n')&&(ch!=EOF))
	{
		s[i]=ch;
		i++;
		ch=getchar();
		if(i==n-1)
		{
			break;
		}
	}
	s[i]='\0';
	return i;
}
int main()
{
	char s[100];
	int a,b,c,len;
	scanf("%d %d %d\n",&a,&b,&c);
	len=read(s,100);
	for(int i=0;i<len;i++)
	{
	//	printf("%c",s[i]);
		if(s[i]!=' ')
		{
			if((s[i]>='a')&&(s[i]<='z'))
			{
				if(s[i]-'a'-a<0)
				{
					printf("%c",'z'+(s[i]-'a'-a+1));
				}
				else
				{
					printf("%c",s[i]-a);
				}
			}
			else if((s[i]>='A')&&(s[i]<='Z'))
			{
				if(s[i]-'A'-b<0)
				{
					printf("%c",'Z'+(s[i]-'A'-b+1));
				}
				else
				{
					printf("%c",s[i]-b);
				}
			}
			else
			{
				printf("%c",s[i]-c);
			}
		}
		else
		{
			printf("%c",s[i]);
		}
	}
	
	return 0;
}
