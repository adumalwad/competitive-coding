#include<stdio.h>
int main()
{
	int h;
	scanf("%d",&h);
	for(int k=1;k<=h;k++)
	{
		if(k%2==0)
		{
			for(int i=h-k+1;i<=h;i++)
			{
				printf("%d",i);
			}
			printf("\n");
			
		}
		else
		{
			for(int i=h;i>h-k;i--)
			{
				printf("%d",i);
			}
			printf("\n");
		}
	}
	return 0;
}
