#include<stdio.h>
#include<stdlib.h>
void sorta(int *a,int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(a[i]>a[j])
			{
				int s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
}
int main()
{
	int n,*a,i=0,j=1,c=1;
	scanf("%d",&n);
	a=(int*)malloc(sizeof(int)*n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",a+i);
	}
	sorta(a,n);
	while((i<n)&&(j<n))
	{
		if(a[j]<=(a[i]+4))
		{
			j++;
		}
		else
		{
			i=j;
			c++;
			j++;
		}
	}
	printf("%d",c);
	return 0;
}
