#include<stdio.h>
int count(int n,int nb,int nc)
{
	if((n<0)||(nb<0)||(nc<0))
	{
		return 0;
	}
	else if(n==0)
	{
		return 1;
	}
	else if((n>0)&&(nb==0)&&(nc==0))
	{
		return 1;
	}
	return count(n-1,nb,nc)+count(n-1,nb-1,nc)+count(n-1,nb,nc-1);
}
int main()
{
	int n,nb=1,nc=2;
	scanf("%d",&n);
	printf("%d",count(n,nb,nc));
	return 0;
}
