#include<stdio.h>
int main()
{
	long long int n;
	int sum;
	scanf("%lld",&n);
	printf("%lld\n",n);
	while((n/10)!=0)
	{
		sum=0;
		while(n!=0)
		{
			sum+=(n%10);
			n/=10;
		}
		n=sum;
		printf("%lld\n",n);
	}
	printf("%lld",n);
	return 0;
}
