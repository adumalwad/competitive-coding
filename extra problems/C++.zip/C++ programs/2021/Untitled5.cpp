#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d\n",m,n);
}
