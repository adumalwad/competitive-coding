#include<stdio.h>
int main()
{
	int n,a=0,b=1,sum=0,count=2;
	scanf("%d",&n);
	if(n==1)
	{
		printf("%d",a);
	}
	else if(n==2)
	{
		printf("%d",b);
	}
	else
	{
		while(count!=n)
		{
			sum=a+b;
			a=b;
			b=sum;
			count++;
		}
	}
	printf("%d\n",b);
	return 0;
}
