#include<stdio.h>
#include<stdlib.h>
void matr_mult(int** a,int** b,int** c,int m,int n)
{
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			*(*(c+i)+j)= (*(*(a+i)+j)) * (*(*(b+i)+j));
		}
		
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			printf("%d ",*(*(c+i)+j));	
		}	
		printf("\n");
	}
}
int main()
{
	int m,n,**a,**b,**c;
	scanf("%d %d",&m,&n);
	
	a=(int**)malloc(m*sizeof(int*));
	b=(int**)malloc(m*sizeof(int*));
	c=(int**)malloc(m*sizeof(int*));
	
	
	for(int i=0;i<n;i++)
	{
		a[i]=(int *)malloc(n*sizeof(int));
	}
	for(int i=0;i<n;i++)
	{
		b[i]=(int *)malloc(n*sizeof(int));
	}
	for(int i=0;i<n;i++)
	{
		c[i]=(int *)malloc(n*sizeof(int));
	}
	
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",(*(a+i)+j));
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",(*(b+i)+j));
		}
	}
/*	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			//scanf("%d",(*(a+i)+j));
			printf("%d ",*(*(a+i)+j));
		}
		printf("\n");
	}
	for(int i=0;i<n;i++)
	{
		printf("%d ",*(b+i));
	}*/
	matr_mult(a,b,c,m,n);
	return 0;
}
