#include<stdio.h>
#include<stdlib.h>
void sum1(int* a,int n)
{
	int sum=*(a+0);
	for(int i=1;i<n;i++)
	{
		sum+=*(a+i);
	}
	printf("%d",sum);
}
int main()
{
	int n,*a;
	scanf("%d",&n);
	a=(int *)malloc(n*sizeof(int));
	for(int i=0;i<n;i++)
	{
		scanf("%d",a+i);
		//printf("%d ",*(a+i));
	}
	sum1(a,n);
	return 0;
}
