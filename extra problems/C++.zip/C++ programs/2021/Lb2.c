#include<stdio.h>
#include<stdlib.h>
int range1(int* a,int n)
{
	int max=*(a+0),min=*(a+0);
	for(int i=1;i<n;i++)
	{
		if((*(a+i))>=max)
		{
			max=*(a+i);
		}
		else if((*(a+i))<=min)
		{
			min=*(a+i);
		}
	}
	return max-min;
}
int main()
{
	int n,*a;
	scanf("%d",&n);
	a=(int *)malloc(n*sizeof(int));
	for(int i=0;i<n;i++)
	{
		scanf("%d",a+i);
		//printf("%d ",*(a+i));
	}
	printf("%d",range1(a,n));
	return 0;
}
