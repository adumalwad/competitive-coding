#include<stdio.h>
#include<stdlib.h>
typedef struct cust_inf
{
	int acn;
	int act;
	char *acna;
	char *acad;
}cust;
int main()
{
	int n;
	cust *c1;
	scanf("%d",&n);
	c1=(cust*)malloc(n*sizeof(cust));
	for(int i=0;i<n;i++)
	{
		c1[i].acna=(char*)malloc(10*sizeof(char));
		c1[i].acad=(char*)malloc(30*sizeof(char));
		scanf("%d %d\n",&c1[i].acn,&c1[i].act);
		scanf("%s %s",c1[i].acna,c1[i].acad);
	//	printf("%d %d\n",c1[i].acn,c1[i].act);
	//	printf("%c %c",c1[i].acna,c1[i].acad);	
	}
	for(int i=0;i<n;i++)
	{
		printf("%d %d ",c1[i].acn,c1[i].act);
		printf("%s %s\n",c1[i].acna,c1[i].acad);	
	}
	return 0;
}
