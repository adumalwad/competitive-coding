#include<stdio.h>
#include<math.h>
int stnum(char a[],int n)
{
	int sum=0;
	for(int i=0;i<n;i++)
	{
		sum+=(a[i]-'0')*pow(10,n-i-1);
	}
	return sum;
}

int cd(int n)
{
	int k=0;
	while(n!=0)
	{
		k++;
		n/=10;
	}
	return k;
}
void numstr(char s[],int sum,int n)
{
	int k,l=pow(10,n-1);
	for(int i=0;i<n;i++)
	{
		k=sum/l;
		s[i]=k+'0';
		//printf("%c %d %d\n",s[i],k,l);
		sum%=l;
		l/=10;
	}
	s[n]='\0';
}
int main()
{
	int la,lb,na,nb;
	scanf("%d %d",&la,&lb);
	char a[la],b[lb];
	scanf("%s %s",&a,&b);
	//printf("%s %s",a,b);
	na=stnum(a,la);
	nb=stnum(b,lb);
//	printf("%d %d\n",na,nb);
	int sum=na+nb;
	int count=cd(sum);
//	printf("%d %d\n",sum,count);
	char s[count+1];
	numstr(s,sum,count);
	printf("%s",s);w
	return 0;
}

