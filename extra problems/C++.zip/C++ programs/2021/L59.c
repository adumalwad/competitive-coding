#include<stdio.h>
int main()
{
	int na,nb,ca=0,cb=0;
	char a,b;
	scanf("%d\n",&na);
	scanf("%c",&a);
	while((a!='|'))
	{
		if(na>0){
		ca++;
		switch(a)
		{
			case '_':
			{
				na--;
				break;
			}
			case '*':
			{
				na=na-2;
				break;
			}
			case '-':
			{
				na--;
				break;
			}
			case '+':
			{
				na++;
				break;
			}
			
		}}
		
		scanf("%c",&a);
	}
	scanf("\n");
	scanf("%d\n",&nb);
	scanf("%c",&b);
	while(b!='|')
	{
		
		if(nb>0){
		
		cb++;
		switch(b)
		{
			case '_':
			{
				nb--;
				break;
			}
			case '*':
			{
				nb=nb-2;
				break;
			}
			case '-':
			{
				nb--;
				break;
			}
			case '+':
			{
				nbprintf("%d %d\n",ca,cb);printf("%d %d\n",ca,cb);++;
				break;
			}
			
		}}
		scanf("%c",&b);
	}
	printf("%d %d\n",ca,cb);
	if(ca>=cb)
	{
		printf("A");
	}
	else
	{
		printf("B");
	}
	return 0;
}
