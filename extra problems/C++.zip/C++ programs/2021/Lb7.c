#include<stdio.h>
#include<stdlib.h>
int count1(int* a,int n,int key)
{
	int c=0;
	for(int i=0;i<n;i++)
	{
		if((*(a+i))<key)
		{
			c++;
		}	
	}
	return c;
}
int main()
{
	int n,*a,k;
	scanf("%d",&n);
	a=(int*) malloc(n*sizeof(int));
	for(int i=0;i<n;i++)
	{
		scanf("%d",a+i);
	}
	scanf("%d",&k);
	printf("%d",count1(a,n,k));
	return 0;
}
