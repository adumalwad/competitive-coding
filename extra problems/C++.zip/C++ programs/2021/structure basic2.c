#include<stdio.h>
#include<stdlib.h>
typedef struct cust_info
{
	int accno;
	int accty;
	char *accname;
	char *accaddr;
}ci;
int main()
{
	int n;
	ci* c;
	scanf("%d",&n);
	c=(ci*)malloc(sizeof(ci)*n);
	for(int i=0;i<n;i++)
	{
		c[i].accname=(char*)malloc(sizeof(char)*30);
		c[i].accaddr=(char*)malloc(sizeof(char)*100);
	//	scanf("%d %d\n",&c[i].accno,&c[i].accty);
	//	scanf("%s %s",c[i].accname,c[i].accaddr);
		scanf("%d %d\n%s %s",&c[i].accno,&c[i].accty,c[i].accname,c[i].accaddr);
	}
	for(int i=0;i<n;i++)
	{
		printf("%d %d %s %s\n",c[i].accno,c[i].accty,c[i].accname,c[i].accaddr);
	}
	return 0;
}
