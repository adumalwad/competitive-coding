#include<stdio.h>
#include<math.h>
int cd(int n)
{
	int k=0;
	while(n!=0)
	{
		k++;
		n/=10;
	}
	return k;
}
int rev(int n)
{
	int k=cd(n),sum=0;
	while(n!=0)
	{
		sum+=(n%10)*pow(10,k-1);
		k--;
		n/=10;
	}
	return sum;
}
int main()
{
	int q,n;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%d",&n);
		printf("rev(%d)=%d\n",n,rev(n));
	}
	return 0;
}
