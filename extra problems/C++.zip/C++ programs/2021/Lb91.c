#include<stdio.h>
#include<stdlib.h>
int count1(char* s,int n)
{
	int c=0;
	for(int i=0;i<n;i++)
	{
		//printf("%c\n",*(s+i));
		if( ((*(s+i))=='A') || ((*(s+i))=='E') || ((*(s+i))=='I') ||((*(s+i))=='O') ||((*(s+i))=='U') ||((*(s+i))=='a') ||((*(s+i))=='e') ||((*(s+i))=='i') ||((*(s+i))=='o') ||((*(s+i))=='u') )
		{
			//printf("%c",*(s+i));
			c++;
		}
	}
	return c;
}
int main()
{
	int n;
	char* s;
	scanf("%d\n",&n);
	s=(char*) malloc(n*sizeof(char));
	for(int i=0;i<n;i++)
	{
		scanf("%c",s+i);
	}
	printf("%d %d",count1(s,n),n-count1(s,n));
	return 0;
}
