#include<stdio.h> //delete element in linked list at specified index
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node* next;
}no;
void display(no* a)
{
	no* cur=a;
	while(cur!=NULL)
	{
		printf("%d ",cur->data);
		cur=cur->next;
	}
	printf("\n");
}
no* make_node(int v)
{
	no* tmp=(no*)malloc(sizeof(no));
	tmp->data=v;
	return tmp;
}
void delete_element(no* a,no* del1)
{
	no* tmp;
	if(a)
	{
		a->next=del1->next;
	}
	tmp=a ? a :del1->next;
	free(del1);
//	return tmp;
}
int main()
{
	int n,v,k;
	no* a;
	scanf("%d",&n);
	a=(no*)malloc(n*sizeof(no));
	for(int i=0;i<n;i++)
	{
		scanf("%d",&v);
		a[i].data=v;
		if(i==n-1)
		{
			a[i].next=NULL;
		}
		else
		{
			a[i].next=a+i+1;
		}
	}
	display(a);
	scanf("%d",&k);
	delete_element(a+k-1,a+k);	 // to insert element at beginning
	display(a);
	return 0;
}
