#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
	int n;
	float *a,*b,*m,sum=0,sum1=0;
	scanf("%d",&n);
	a=(float *)malloc(sizeof(float)*n);
	b=(float *)malloc(sizeof(float)*n);
	m=(float *)malloc(sizeof(float)*n);
	for(int i=0;i<n;i++)
	{
		scanf("%f",(a+i));
	}
	for(int i=0;i<n;i++)
	{
		scanf("%f",(b+i));
		sum+=(*(a+i)) * log((*(a+i)) / (*(b+i)));
		*(m+i)=(*(a+i)+*(b+i))/2;
		sum1+=(*(a+i)) * log((*(a+i)) / (*(m+i))) +(*(b+i)) * log((*(b+i)) / (*(m+i)));
	}
	/*for(int i=0;i<n;i++)
	{
		printf("%f ",*(b+i));
	}*/
	printf("KL value=%f\nJS value=%f",sum,sum1/2);
	return 0;
}
