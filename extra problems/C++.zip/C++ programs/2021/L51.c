#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	int max=a,max1=-1;
	while(a!=(-1))
	{
		scanf("%d",&a);
		if(a>max)
		{
			max=a;
		}
		else if((a<max) && (a>max1))
		{
			
			max1=a;
		}
	}
	printf("%d",max1);
	return 0;
}
