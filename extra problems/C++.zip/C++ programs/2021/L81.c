#include<stdio.h>
int countsub(int a[],int s,int n,int sum)
{
	if(sum==0)
	{
	//	printf("a[n]=%d\n",a[n]);
		a[n]++;
		return 1;
	}
	else if(sum<0)
	{
		return 0;
	}
	else
	{
		for(int i=s;i<n;i++)
		{
			//printf("s=%d sum=%d a[i]=%d\n",s,sum,a[i]);
			countsub(a,i,n,sum-a[i]);
		}
	}
}
int main()
{
	int n,t;
	scanf("%d",&n);
	int a[n+1];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d",&t);
	a[n]=0;
	for(int i=0;i<t;i++)
	{
		int sum,k;
		scanf("%d",&sum);
		k=sum;
	//	printf("%d\n",a[n]);
	//	printf("%d",countsub(a,0,n,sum,k));
		countsub(a,0,n,sum);
		printf("%d\n",a[n]);
	}
	return 0;
}
