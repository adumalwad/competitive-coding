#include<stdio.h>
#include<string.h>

int main()
{
	int n;
	scanf("%d",&n);
	char a[n][20],temp[100];

	for(int i=0; i<n; ++i)
        scanf("%s[^\n]",a[i]);

	for(int k=0;k<n;k++)
	{
		for(int l=k;l<n;l++)
		{
			if(strcmp(a[k],a[l])>=0)
			{
				strcpy(temp, a[k]);
 				strcpy(a[k], a[l]);
 			 	strcpy(a[l], temp);
				
			}
		}
	}
	for(int k=0;k<n;k++)
	{
		printf("%s ",a[k]);
	}

	return 0;
}
