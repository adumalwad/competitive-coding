#include<stdio.h>
int main()
{
	int n,c=0;
	scanf("%d",&n);
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(a[i]>a[j])
			{
				int s=a[i];
				a[i]=a[j];
				a[j]=s;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		if(a[i]!=b[i])
		{
			for(int j=i+1;j<n;j++)
			{
				if(b[j]==a[i])
				{
					int s1=b[i];
					b[i]=b[j];
					b[j]=s1;
					c++;
				}
			}
		}
	}
	printf("%d",c);
	return 0;
}
