#include<stdio.h>
int arecollinear(int x1,int y1,int x2,int y2,int x3,int y3)
{
	if((x1-x2)*(y2-y3)-(x2-x3)*(y1-y2)==0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	int q,x1,y1,x2,y2,x3,y3;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		scanf("%d %d\n",&x1,&y1);
		scanf("%d %d\n",&x2,&y2);
		scanf("%d %d",&x3,&y3);
		if(arecollinear(x1,y1,x2,y2,x3,y3)==1)
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}	
	}
	return 0;
}
