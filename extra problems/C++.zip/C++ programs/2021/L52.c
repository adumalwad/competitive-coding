#include<stdio.h>
int main()
{
	int n;
	char ch,ch1;
	scanf("%d\n",&n);
	scanf("%c",&ch);
	while(ch!='*')
	{
		if((ch!='+') && (ch!='-') && (ch!='.') && (ch!='*'))
		{
			printf("invalid");
			return 0;
		}
		for(int i=1;i<n-1;i++)
		{
			ch1=ch;
			scanf("%c",&ch);
			if((ch!='+') && (ch!='-') && (ch!='.') && (ch!='*'))
			{
				printf("invalid");
				return 0;
			}
			else if(((ch1=='+')&&(ch=='-'))||((ch1=='-')&&(ch=='+')))
			{
				printf("short circuit");
				return 0;
			}
		}
		ch1=ch;
		scanf("%c\n",&ch);
		if((ch!='+') && (ch!='-') && (ch!='.') && (ch!='*'))
		{
			printf("invalid");
			return 0;
		}
		else if(((ch1=='+')&&(ch=='-'))||((ch1=='-')&&(ch=='+')))
		{
			printf("short circuit");
			return 0;
		}
		scanf("%c",&ch);
	}
	printf("Okay");
	return 0;
}
