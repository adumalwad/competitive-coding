#include "bc.h"
#include<iostream>
#include<string>
using namespace std;
int main()
{
	bc bo();
	
	return 0;
}

