#include "bc3.h"
#include "bc2.h"
#include "bc.h"
#include<iostream>
using namespace std;

int main()
{
	/*bc bo;           // constructor
	
	/*bc2 bo2;           // constant object constant function
	const bc2 cbo2;
	bo2.regular_func();
	bo2.constant_func();
	cbo2.constant_func();*/
	
	/*bc3 bo3(5 ,10);                 // member initializer
	bo3.print();*/
	
	bc4 bo4;          // composition of classes
	bc5 bo5;
	return 0;
}
