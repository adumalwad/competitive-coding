#include<iostream>
#include<string>
#include "bc1.h"
using namespace std;
/*class bc{
	public:
		bc(int a,int b,int c)
		{
			p=a;
			q=b;
			r=c;
		}
	private:
		int p,q,r;
		string strl;
};*/
int main()
{
	bc1 bo1;
	bc1* pbo1=&bo1;
	
	bo1.print_val();
	pbo1->print_val();
	return 0;
}

