#ifndef BC2_H
#define BC2_H

class bc2
{
	public:
		bc2();
		void regular_func();
		void constant_func()const;
		~bc2();
	protected:
};

#endif
