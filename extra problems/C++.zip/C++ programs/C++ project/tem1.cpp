#include "bc.h"
#include "bc1.h"
#include "bc2.h"
#include "bc3.h"
#include "bc4.h"
#include "bc5.h"
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<string>
using namespace std;
int main()
{
	/* bc bo;        // constructor
	/*
	 bc1 bo1;        // arrow member
	 bc1* pbo1=&bo1;
	 bo1.print_val();
	 bo1->print_val();
	*/
	/*
	bc2 bo2;                  // constant object need constant functions
	const bc2 cbo2;
	bo2.regular_func();
	cbo2.constant_func();
	cout << "This is a main()"<< endl;
	*/
	
	bc3 bo3(10,5);       //member initializer
	bo3.print();
	
	cout << "Hello World";
	return 0;
}

