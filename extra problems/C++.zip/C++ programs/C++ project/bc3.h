#ifndef BC3_H
#define BC3_H

class bc3
{
	public:
		bc3(int x,int y);
		void print(); 
		~bc3();
	private:
		int regvar;
		const int constvar;
};

#endif

