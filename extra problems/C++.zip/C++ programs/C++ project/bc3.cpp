#include "bc3.h"
#include "bc2.h"
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<string>
using namespace std;
bc3::bc3(int x ,int y)
:regvar(x),constvar(y)
{
	
}
void bc3::print()
{
	cout << " value of reg: " << regvar <<" value of constvar: "<< constvar << endl;
}
bc3::~bc3()
{
}
#include "bc3.h"
