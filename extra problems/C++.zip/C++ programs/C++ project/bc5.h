#ifndef BC5_H
#define BC5_H

class bc5
{
	public:
	protected:
};

#endif
