#include "bc2.h"
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<string>
using namespace std;

bc2::bc2()
{
	/*int i=0;
	cout << i <<" This is constructor"<< endl;
	i++;*/
}
void bc2::regular_func()
{
	cout << "This a regular func" << endl;
}
void bc2::constant_func() const
{
	cout << "This a constant func" << endl;
}
bc2::~bc2()
{
	/*int j=0;
	cout << j << " This is destructor"<<endl;
	j++;*/
}
