#ifndef BC_H
#define BC_H

class bc
{
	public:
		bc();
	private:
};

#endif

