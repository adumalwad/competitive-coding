#ifndef BC1_H
#define BC1_H

class bc1
{
	public:
		bc1();
		void print_val();
	protected:
};

#endif
