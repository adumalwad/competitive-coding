#include "bc1.h"
#include<iostream>
#include<string>
using namespace std;

bc1::bc1()
{
}
void bc1::print_val()
{
	cout <<"Hello World!!\n";
}
