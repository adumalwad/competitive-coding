#include<iostream>
#include<cmath>
#include<cstdlib>
#include<string>
#include "bc2.h"
using namespace std;
int main()
{
	bc2 bo2;
	cout << "This is main()"<< endl;
	return 0;
}

