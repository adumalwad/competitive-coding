#ifndef BC4_H
#define BC4_H

class bc4
{
	public:
	private:
		int date,month,year;
};

#endif
