#include "bc.h"
#include<iostream>
#include<string>
using namespace std;
bc::bc()
{
	cout << "BC constructor"<< endl;
}
