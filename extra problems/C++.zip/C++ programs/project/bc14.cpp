#include "bc13.h"
#include "bc14.h"
#include<string>
#include<iostream>
using namespace std;

bc14::bc14()
{
}
void bc14::attack()
{
	cout << "I am ninja "<< p << endl;
}
bc14::~bc14()
{
}
