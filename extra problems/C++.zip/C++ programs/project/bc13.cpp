#include "bc13.h"
#include "bc14.h"
#include<string>
#include<iostream>
using namespace std;

bc13::bc13()
{
}
void bc13::setp(int val)
{
	p=val;
}
bc13::~bc13()
{
}
