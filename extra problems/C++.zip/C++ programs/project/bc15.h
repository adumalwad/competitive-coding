#ifndef BC15_H
#define BC15_H
#include "bc13.h"

class bc15 : public bc13
{
	public:
		bc15();
		void attack();
		~bc15();
	protected:
};

#endif
