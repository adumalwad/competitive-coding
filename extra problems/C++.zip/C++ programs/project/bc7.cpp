#include "bc7.h"
#include "bc8.h"
#include<string>
#include<iostream>
using namespace std;
bc7::bc7()
{
}
void bc7::print_text()
{
	cout  << "This is class bc7" << endl;
}
bc7::~bc7()
{
}
