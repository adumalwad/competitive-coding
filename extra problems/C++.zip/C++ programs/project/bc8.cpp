#include "bc8.h"
#include "bc7.h"
#include<string>
#include<iostream>
using namespace std;
bc8::bc8()
{
}

bc8::~bc8()
{
}
