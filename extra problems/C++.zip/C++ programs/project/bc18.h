#ifndef BC18_H
#define BC18_H

#include "bc16.h"

class bc18 : public bc16
{
	public:
		bc18();
		void attack();
		~bc18();
	protected:
};

#endif
