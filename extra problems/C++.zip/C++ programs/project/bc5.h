#ifndef BC5_H
#define BC5_H
#include<string>
#include "bc4.h"
using namespace std;
class bc5
{
	public:
		bc5(string fn,string ln,bc4* obj);
		void print();
	private:
		bc4 dob;
		string fname;
		string lname;
};

#endif
