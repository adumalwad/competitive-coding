#ifndef BC11_H
#define BC11_H

class bc11
{
	public:
		bc11();
		~bc11();
	protected:
};

#endif
