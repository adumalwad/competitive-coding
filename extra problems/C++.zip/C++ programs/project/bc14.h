#ifndef BC14_H
#define BC14_H

class bc14 : public bc13
{
	public:
		bc14();
		void attack();
		~bc14();
	protected:
};

#endif
