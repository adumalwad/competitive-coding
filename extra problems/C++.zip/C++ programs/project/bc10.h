#ifndef BC10_H
#define BC10_H

#include "bc9.h"

class bc10 : public bc9
{
	public:
		void pub_access(int a ,int b);
	protected:
};

#endif
