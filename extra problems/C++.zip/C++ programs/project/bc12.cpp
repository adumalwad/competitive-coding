#include "bc11.h"
#include "bc12.h"
#include<string>
#include<iostream>
using namespace std;


bc12::bc12()
{
	cout << "derived class constructor" << endl;
}

bc12::~bc12()
{
	cout << "derived class deconstructor" << endl;
}
