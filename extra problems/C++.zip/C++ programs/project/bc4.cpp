#include "bc4.h"
#include<iostream>
using namespace std;

bc4::bc4(int d,int m,int y)
:date(d),month(m),year(y)
{
	
}
void bc4::print_date()
{
	cout << "Birth Date is: "<<date <<"/"<< month <<"/" <<year<<endl;
}

