#include<iostream>
using namespace std;

template <class na>
int main()
{
	
}
