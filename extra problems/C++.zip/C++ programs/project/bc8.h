#ifndef BC8_H
#define BC8_H
#include "bc7.h"
class bc8 : public bc7
{
	public:
		bc8();
		~bc8();
};

#endif
