#ifndef BC12_H
#define BC12_H

class bc12 : public bc11
{
	public:
		bc12();
		~bc12();
	protected:
};

#endif
