#include "bc16.h"
#include "bc17.h"
#include "bc18.h"
#include<string>
#include<iostream>
using namespace std;
bc18::bc18()
{
}
void bc18::attack()
{
	cout << "Monster enemy attack" << endl;
}
bc18::~bc18()
{
}
