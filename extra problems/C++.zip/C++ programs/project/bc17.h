#ifndef BC17_H
#define BC17_H

#include "bc16.h"
class bc17 : public bc16
{
	public:
		bc17();
		void attack();
		~bc17();
	protected:
};

#endif
