#include "bc5.h"
#include "bc4.h"
#include<iostream>
#include<string>
using namespace std;

bc5::bc5(string fn,string ln,bc4* obj)
:fname(fn),lname(ln),dob(*obj)
{
}
void bc5::print()
{
	cout << fname << " " << lname <<" " ;
	dob.print_date();
}

