#include<iostream>
using namespace std;

template <class na>
na sum1(na a,na b)
{
	return a+b;
}
int main()
{
	int a=1,b=2;
	float c=3.05;
	cout << sum1(a,b);
	//cout << sum2(a,c);
	return 0;	
}
