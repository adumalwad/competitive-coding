#include "bc9.h"
#include "bc10.h"
#include<string>
#include<iostream>
using namespace std;

void bc9::print_val()
{
	cout << "pubvar: " << pubvar << " " << "provar: "<< provar << endl;
}
