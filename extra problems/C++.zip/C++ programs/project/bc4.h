#ifndef BC4_H
#define BC4_H

class bc4
{
	public:
		bc4(int d,int m,int y);
		void print_date();
	private:
		int date,month,year;
};

#endif
