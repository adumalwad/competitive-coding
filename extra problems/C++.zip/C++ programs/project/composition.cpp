#include "bc5.h"
#include "bc4.h"
#include "bc7.h"
#include "bc8.h"
#include "bc9.h"
#include "bc10.h"
#include "bc11.h"
#include "bc12.h"
#include "bc13.h"
#include "bc14.h"
#include "bc15.h"
#include "bc16.h"
#include "bc17.h"
#include "bc18.h"
#include<string>
#include<iostream>
using namespace std;

/*class bc6{
	public:
		bc()
		{
			a=0;
		}
	private:
		int a;
	
	friend void pra(bc6 *bf);
};
void pra(bc6 *bf)
{
	bf->a=99;
	cout << bf->a;
}*/

int main()
{
	/*int d,m,y;       //class composition
	string fna,lna;
	cin >> d >> m >> y;
	bc4 bo4(d,m,y);
	cin >> fna >> lna;
	//bo4.print_date();
	bc5 bo5(fna,lna,&bo4);
	bo5.print();*/
/*	bc6 bo;
	pra(&bo);*/
	
	/*
	class bc7 bo7;       // class inheritance
	bo7.print_text();
	class bc8 bo8;
	bo8.print_text();
	*/
	
	/*
	bc10 bo10;                 //protected members will be inherited (but not private)
	bo10.pub_access(1,30);
	bo10.print_val();
	*/
	
	/*
	bc12 bo12;                     //base & derived class execution order
	*/
	
	/*	
	bc14 bo14;
	bc15 bo15;
	
	bo14.setp(10);
	bo14.attack();
	bc14* pbo14=&bo14;
	pbo14->setp(100);
	bo14.attack();
	pbo14->attack();

	bo15.setp(15);
	bo15.attack();
	bc15* pbo15=&bo15;
	pbo15->setp(16);
	bo15.attack();
	pbo15->attack();
	*/
	
	/*                                 
	bc14 bo14;                       //polymorphism
	bc15 bo15;
	bc13* pbo14=&bo14;
	bc13* pbo15=&bo15;
	pbo14->setp(29);
	pbo15->setp(19);
	//pbo15->attack();           // this will give you error as there in no attck func in bc13 class
	bo14.attack();
	bo15.attack();
	*/
	 
	/*	
	bc17 bo17;                   // virtual functions
	bc18 bo18;
	bc16* pbo17=&bo17;
	bc16* pbo18=&bo18;
	pbo17->attack();
	pbo18->attack();
	*/
	
	return 0;
}
