#include "bc15.h"
#include "bc14.h"
#include<string>
#include<iostream>
using namespace std;
bc15::bc15()
{
}
void bc15::attack()
{
	cout << "I am Monster "<< p << endl;
}
bc15::~bc15()
{
}
