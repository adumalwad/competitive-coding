#include "bc16.h"
#include "bc17.h"
#include "bc18.h"
#include<string>
#include<iostream>
using namespace std;

bc16::bc16()
{
}
void bc16::attack(){
}
bc16::~bc16()
{
}
