#include "bc11.h"
#include "bc12.h"
#include<string>
#include<iostream>
using namespace std;


bc11::bc11()
{
	cout << "base class constructor\n";
}

bc11::~bc11()
{
	cout << "base class deconstructor\n";
}
