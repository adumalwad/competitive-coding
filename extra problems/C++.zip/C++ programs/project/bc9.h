#ifndef BC9_H
#define BC9_H

class bc9
{
	public:
		int pubvar;
		void print_val();
	protected:
		int provar; 
	private:
		int privar;
};

#endif
