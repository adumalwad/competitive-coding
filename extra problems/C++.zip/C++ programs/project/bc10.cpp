#include "bc9.h"
#include "bc10.h"
#include<string>
#include<iostream>
using namespace std;

void bc10::pub_access(int a ,int b)
{
	pubvar=a;
	provar=b;
	//privar=20;
}
