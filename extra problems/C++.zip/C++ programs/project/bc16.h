#ifndef BC16_H
#define BC16_H

class bc16
{
	public:
		bc16();
		virtual void attack();
		~bc16();
};

#endif
