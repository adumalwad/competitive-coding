#include "bc16.h"
#include "bc17.h"
#include "bc18.h"
#include<string>
#include<iostream>
using namespace std;
bc17::bc17()
{
}
void bc17::attack()
{
	cout << "Ninja enemy attack" << endl;
}
bc17::~bc17()
{
}
