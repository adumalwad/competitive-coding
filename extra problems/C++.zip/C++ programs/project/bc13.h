#ifndef BC13_H
#define BC13_H

class bc13
{
	public :
		bc13();
		void setp(int val);
		~bc13();
	protected:
		int p;
};

#endif
