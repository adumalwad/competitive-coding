#ifndef BC7_H
#define BC7_H

class bc7
{
	public:
		bc7();
		void print_text();
		~bc7();
};

#endif
