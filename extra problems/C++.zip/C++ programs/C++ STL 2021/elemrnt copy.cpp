#include<iostream>
#include<vector>
#include<iterator>
#include<algorithm>
#define all(cont) cont.begin(),cont.end()
#define tr(cont,it) for(typeof(cont.begin()) it=cont.begin();it!=cont.end();it++)
using namespace std;
int main()
{
	vector<int> v1={1,4,2,5,3,7,5,9,7};
	vector<int> v2={10,13,16,18,12,19,20};
	cout << "Before copy\nv1: ";
	tr(v1,it)
	{
		cout << *it <<" ";
	}
	v1.resize(v1.size()+v2.size());
	//copy(all(v2),k);
	copy(all(v2),v1.end()-v2.size());
	cout<< "\nAfter copying v2 into v1\nv1: ";
	tr(v1,it)
	{
		cout << *it <<" ";
	}
	/*cout<< "\nAfter copying v2 into v1\nv1: ";
	for(auto it=v1.begin();it!=v1.end();it++)
	{
		cout << *it <<" ";
	}*/
	return 0;
}

