#include<bits/stdc++.h>
#define all(cont) cont.begin(),cont.end()
#define tr(cont,it) for(typeof(cont.begin()) it=cont.begin();it!=cont.end();it++)
using namespace std;
int main()
{
	map <string,int> m;
	m["anup"]=1;
	m["aniket"]=5;
	m["mummy"]=21;
	m["daddy"]=15;
	vector<pair<string,int> >v(all(m));
	vector<pair<string,int> >::iterator it;
	for( it = v.begin(); it!=v.end();it++)
	{
		cout << it->first << " " << it->second << endl;
	}
	return 0;
}

