#include<bits/stdc++.h>
#define all(v) v.begin(),v.end()
#define arll(v) v.rbegin(),v.rend()
#define tr(v,it) for(auto it=v.begin();it!=v.end();it++)
using namespace std;
int main()
{
	int t,q,x;
	char ch;
	cin >> t;
	vector<int> v;
	for(int i=0;i<t;i++)
	{
		cin >> q;
		for(int j=0;j<q;j++)
		{
			cin >> ch;
			switch(ch)
			{
				case 'a':
				{
					cin >> x;
					v.push_back(x);
					break;
				}
				case 'b':
				{
					sort(all(v));
					break;
				}
				case 'c':
				{
					reverse(all(v));
					break;	
				}
				case 'd':
				{
					cout << v.size() << " ";
					break;
				}
				case 'e':
				{
					//cout << "output: ";
					tr(v,it)
					{
						cout << *it << " ";
					}
					break;
				}
				case 'f':
				{
					sort(arll(v));
					break;
				}
			}
		}
		cout << endl;
		v.clear();
	}
	return 0;
}

