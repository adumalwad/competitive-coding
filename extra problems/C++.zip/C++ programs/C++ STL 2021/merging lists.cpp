#include<bits/stdc++.h>
#define all(cont) cont.begin(),cont.end()
#define tr(cont,it) for(typeof(cont.begin()) it=cont.begin();it!=cont.end();it++)
using namespace std;
int main()
{
	int data1[] = {1,2,5,6,8,9,10};
	int data2[] = {0,2,3,4,7,8,10};
	vector < int > v1(data1, data1 + sizeof(data1) / sizeof(data1[0]));
	vector < int > v2(data2, data2 + sizeof(data2) / sizeof(data2[0]));
	vector < int > tmp( max(v1.size(), v2.size()));
	vector < int > res = vector < int > (tmp.begin(), set_intersection(all(v1), all(v2), tmp.begin()));
	
	for(auto it=res.begin();it!=res.end();it++)
	{
		cout << *it << " ";
	}
	return 0;
}

