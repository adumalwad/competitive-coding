#include<stdio.h>
int main()
{
	printf("\\ is escape char\n\\n is new line\n\' is single quote\n\" is double quote");
	return 0;
}