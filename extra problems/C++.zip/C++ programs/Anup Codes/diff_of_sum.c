#include<stdio.h>
int main()
{
	float a,b;
	a=1+2+3;
	b=(-5)+10+1;
	printf("%f",a-b);
	return 0;
}