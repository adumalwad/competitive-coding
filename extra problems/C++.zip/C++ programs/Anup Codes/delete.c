#include<stdio.h>
void sort_arr(int b[],int c[],int n)
{
	int swap1=0,swap2=0;
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(c[j]<c[i])
			{
				swap1=c[i];
				c[i]=c[j];
				c[j]=swap1;

				swap2=b[i];
				b[i]=b[j];
				b[j]=swap2;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		printf("%d ",b[i]);
	}
}
void find_mode(int a[],int b[],int n)
{
	int c[n],k=0;
	for(int i=0;i<n;i++)
	{
		//printf("%d ",a[i]);
		if(a[i]==0)
		{
			continue;
		}
		else
		{
			c[k]=1;
			b[k]=a[i];
			for(int j=i+1;j<n;j++)
			{
				if(a[j]==a[i])
				{
					c[k]++;
					a[j]=0;
				}
			}
			//printf("b[%d]=%d c[%d]=%d\n",k,b[k],k,c[k]);
			k++;
		}
	}
	for(int x=0;x<k;x++)
	{
		printf("%d %d\n",b[x],c[x]);
	}
	sort_arr(b,c,k);

}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	/*for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}*/
	find_mode(a,b,n);

	return 0;
}