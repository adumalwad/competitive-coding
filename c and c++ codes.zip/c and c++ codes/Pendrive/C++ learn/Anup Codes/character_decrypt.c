#include<stdio.h>
int main()
{
	char a,b,c,e,f;
	int x;
	//scanf("%c",&a);
	scanf("%c%c%c%c%c",&a,&b,&c,&e,&f);
	scanf("%d",&x);
	printf("%c%c%c%c%c",((a-'a'+1)+x)%26+'a'-1,((b-'a'+1)+x)%26+'a'-1,((c-'a'+1)+x)%26+'a'-1,((e-'a'+1)+x)%26+'a'-1,((f-'a'+1)+x)%26+'a'-1);
	return 0;
}