#include<stdio.h>
int main()
{
	int a=1+4,b=3+7;
	float c=1.75;
	printf("%f",((float)a/b)+c);
	return 0;
}