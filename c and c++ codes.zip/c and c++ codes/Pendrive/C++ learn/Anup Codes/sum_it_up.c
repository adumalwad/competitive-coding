#include<stdio.h>
int main()
{
	printf("%d",10+20+30);
	return 0;
}