#include<stdio.h>
int main()
{
	printf("\"ESC\"-\"101\"");
	return 0;
}