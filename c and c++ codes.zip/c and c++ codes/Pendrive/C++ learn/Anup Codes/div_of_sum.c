#include<stdio.h>
int main()
{
	float a=(-1)+(-9)+(-5),b=(-6)+7+(-8);
	printf("%f",a/b);
	return 0;
}