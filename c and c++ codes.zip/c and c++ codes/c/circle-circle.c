#include<stdio.h>
#include<math.h>
int main()
{
	float x1,y1,r1,x2,y2,r2,dist;
	scanf("%f %f %f %f %f %f",&x1,&y1,&r1,&x2,&y2,&r2);
	dist=sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
	if(dist<abs(r1-r2))
	{
		printf("encloses");
	}
	else if((dist==(r1+r2))||(dist==abs(r1-r2)))
	{
		printf("touches");
	}
	else if((dist<(r1+r2)) && (dist > abs(r1-r2)))
	{
		printf("intersects");
	}
	else
	{
		printf("they  are far away");
	}
	return 0;
}
