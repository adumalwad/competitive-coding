#include<stdio.h>
#include<math.h>
int main()
{
	float x;
	scanf("%d",&x);
	if(x<(-1))
	{
		printf("%f",-x);
	}
	else if((x>=-1) && (x<0))
	{
		printf("1");
	}
	else if((x>=0) && (x<M_PI))
	{
		printf("%f",cos(x));
	}
	else
	{
		printf("%f",-exp(M_PI-x));
	}
	return 0;
}
