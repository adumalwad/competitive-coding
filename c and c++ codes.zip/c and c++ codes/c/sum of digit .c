#include<stdio.h>
int main()
{
	int n,sd=0,sd1=0,sd2=0;
	scanf("%d",&n);
	//printf("n=%d\n",n);
	while(n>0)
	{
		sd=sd+n%10;
		n=n/10;
	}
	
	if(sd<10)
	{
		printf("sd=%d",sd);
		return 0;
	}
	
	//printf("sd=%d\n",sd);
	
	while(sd>0)
	{
		sd1=sd1+sd%10;
		sd=sd/10;
	}
	
	if(sd1<10)
	{
		printf("sd1=%d",sd1);
		return 0;
	}
	//printf("sd1=%d\n",sd1);
	while(sd1>0)
	{
		sd2=sd2+sd1%10;
		sd1=sd1/10;
		
	}
	if(sd2<10)
	{
		printf("sd2=%d",sd2);
		return 0;
	}
	
	return 0;
}
