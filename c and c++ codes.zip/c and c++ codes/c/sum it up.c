#include<stdio.h>
int main(int argc, char const *argv[])
{
	/* code */
	printf("%d",10+20+50);
	return 0;
}