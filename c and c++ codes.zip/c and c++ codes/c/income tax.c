#include<stdio.h>
int main()
{
	int ti;
	float tax;
	scanf("%d",&ti);
//	printf("%d\n",ti);
	if(ti<=200000)
	{
		tax=0;
		printf("%.2f",tax);
	}
	else if((ti>200000)&& (ti<=500000))
	{
		tax=((float)ti-200000)*0.1;
		printf("%.2f",tax);
	}
	else if((ti>500000) && (ti<=1000000))
	{
		tax=30000 +((float)ti-500000)*0.2;
		printf("%.2f",tax);
	}
	else
	{
		tax=130000 +((float)ti-1000000)*0.3;
		printf("%.2f",tax);
	}
//	printf("%.2f",tax);
	return 0;
}
