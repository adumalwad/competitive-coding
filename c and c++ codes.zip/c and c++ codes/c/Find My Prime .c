#include<stdio.h>
int main()
{
	int n,i,count=0,j;
	scanf("%d",&n);
	if((n==1)||(n==2))
	{
		printf("%d",n);
		return 0;
	}
	for(i=n;i>=2;i--)
	{
		count=0;
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				count++;
				break;
			}
		}
		if(count==0)
		{
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}
