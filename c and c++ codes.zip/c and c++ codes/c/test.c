#include<stdio.h>
#include<math.h>
int main()
{
	float x,y;
	int d,i;
	scanf("%f %f %d",&x,&y,&d);
	float a=x/y;
	a = a*pow(10,d);
	printf("%d\n",a);
	int b = a;
	a = (float)b/pow(10,d);
	printf("%f",&a);
//	printf("%d",(int)(x/y));
/*	if(d!=0)
	{
		printf(".");
	}
	if(y==0)
	{
		printf("NOT DEFINED");
		return 0;
	}
	x=(x-((int)(x/y))*y) *10;
	for(i=0;i<d;i++)
	{
		printf("%d",(int)(x/y));
		x=(x-((int)(x/y))*y) *10;
			
	}*/
	return 0;
}
