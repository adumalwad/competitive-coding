#include <stdio.h>
int main(int argc, char const *argv[])
{
	int n,i=0;
	char ch;
	scanf("%d\n",&n);
	scanf("%c",&ch);
//	printf("%d %c\n",n,ch);

	if((ch!='+') && (ch!='-') && (ch!='.') && (ch!='*')  )
	{
		printf("invalid");
		return 0;
	}
	
	
	while(ch!='*')
	{
			
		for(i=1;i<n;i++)
		{
			char c=ch;
			scanf("%c",&ch);
			
			if((ch!='+') && (ch!='-') && (ch!='.') && (ch!='*')  )
			{
				printf("invalid");
				return 0;
			}
			if(((c=='+') && (ch=='-')) || ((c=='-') && (ch == '+')))
			{
				printf("short circuit");
				return 0;
			}
			
		}
		scanf("%c\n",&ch);
	
	}

	printf("okay");
	return 0;
}
