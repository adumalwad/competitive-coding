#include<stdio.h>
int main()
{
	int n,max=0,max2=0,count=0; 
	scanf("%d",&n);
	while(n!=-1)
	{
	//	max2=max;
		if(n>max)
		{
		//	printf("%d\n",n);
			max2=max;
			max=n;
			
		}
		if((n>max2)&&(n<max))
		{
			count++;
			max2=n;               //  THIS CODE HAS PROBLEM FOR (2 2 2 3 -1) i.e maxin=mum nuber is at the end of serirs
		//`	printf("%d\n",n);     //  GIVES WRONG ANSWER WHEN 2nd LARGEST IS AT THE BEGINNING OF LIST (issue solved in line 12)
		}
		scanf("%d",&n);
	}
	if(count==0)
	{
		printf("-1");
		//return 0;                  
	}
	printf("%d",max2);
	return 0;
}
