#include<stdio.h>
int main()
{
	int m,n,sum=0,i,j=0;
	scanf("%d %d",&m,&n);
//	printf("m=%d n=%d\n",m,n);
	int a[m],b[n],c[m+n];
	for(i=0;i<m;i++)
	{
		scanf("%d",&a[i]);
		c[i]=a[i];
		sum=sum+c[i];
		printf("c[%d]=%d ",i,c[i]);
	}
	//printf("\nsum1=%d\n",sum);
	for(j=0;j<n;j++);
	{
		printf("j=%d\n",j);
		scanf("%d",&b[j]);
		c[m+j]=b[j];
		sum=sum+c[m+j];
		printf("c[%d]=%d ",m+j,c[m+j]);
	}
	printf("\nsum2=%d\n",sum);
/*	float mean=(float)sum/(m+n);
	printf("\n%.2f",mean);*/
	return 0;
}
