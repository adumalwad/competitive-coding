#include<stdio.h>
int main()
{
	int P;
	float T,R,SI,amount;
	scanf("%d %f%f",&P,&T,&R);
	printf("%.2f %d",(P*T*R)/100,(int)(P*(1+(T*R/100))));
	return 0;
}
