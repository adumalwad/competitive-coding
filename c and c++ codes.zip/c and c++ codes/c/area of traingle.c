#include<stdio.h>
#include<math.h>
int main()
{
	float a,s=2;
	scanf("%f",&s);
	a=( (float) sqrt(3)/4)*s*s;
	printf("%.3f %d",a,(int)a);
	return 0;

}