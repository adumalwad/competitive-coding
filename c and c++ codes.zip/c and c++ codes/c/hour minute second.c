#include<stdio.h>
int main()
{
	int time,hour,minutes,seconds;
	scanf("%d", &time);
	printf("%d\n",time);
	hour=time / 3600;
	time=time % 3600;
	minutes=time / 60;
	time=time % 60;
	seconds=time;
	printf("%d Hours, %d Minutes, %d Seconds",hour,minutes,seconds);

	return 0;
}
