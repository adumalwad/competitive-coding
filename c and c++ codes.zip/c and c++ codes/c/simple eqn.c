#include<stdio.h>
int main()
{
	int A=1+4,B=3+7;
	float C=1.75,eqn;
	eqn=( (float) A/B )+C;
	printf("%f\n", eqn);
	return 0;
}