#include<stdio.h>
int main()
{
	float a1,b1,c1,a2,b2,c2,x,y;
	scanf("%f %f %f %f %f %f",&a1,&b1,&c1,&a2,&b2,&c2);
	x=(b1*c2-b2*c1)/(a1*b2-a2*b1);
	y=-(a1*c2-a2*c1)/(a1*b2-a2*b1);
	printf("%.2f %.2f",x,y);
	return 0;
}
