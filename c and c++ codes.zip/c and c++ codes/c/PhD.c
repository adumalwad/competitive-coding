#include<stdio.h>
int main()
{
	char ch;
	int ct=0,cs=0,cf=0,ci=0,cn=0,cd=0,cp=0;
	scanf("%c",&ch);
	while(ch!='O')
	{
		if((ch!='T') && (ch!='S')&& (ch!='F')&& (ch!='I')&& (ch!='N')&& (ch!='D')&& (ch!='P'))
		{
			printf("INVALID");
			return 0;
		}
		switch(ch)
		{
			case 'T':
				{
					ct++;
					break;
				}
			case 'S':
				{
					cs++;
					break;
				}
			case 'F':
				{
					cf++;
					break;
				}
			case 'I':
				{
					ci++;
					break;
				}
			case 'N':
				{
					cn++;
					break;	
				}
			case 'D':
				{
					cd++;
					break;
				}
			case 'P':
				{
					cp++;
					break;
				}
				
		}
		scanf("%c",&ch);
	}
	if((ct==3) && (cs==1) &&(cf<=6) && (ci>=3) &&(cn>=3) && (cd<=30))
	{
		printf("DOCTOR");
	}
	else
	{
		printf("NOT DOCTOR");
	}
	return 0;
}
