#include<stdio.h>
int main()
{
	char ch;
	int n;
	scanf("%c",&ch);
	scanf("%d",&n);
	printf("%c %d %c %d\n%d",ch,ch,ch+n,ch+n,ch<96);
	return 0;
}
