#include<stdio.h>
#include<math.h>
int main()
{
	float x,y,r,x1,y1,dist;
	scanf("%f %f %f %f %f",&x,&y,&r,&x1,&y1);
	dist=sqrt((x1-x)*(x1-x)+(y1-y)*(y1-y));
	if(dist<r)
	{
		printf("inside circle");	
	}
	else if(dist== r)
	{
		printf("on circle");
	}
	else
	{
		printf("outside circle");
	}
	
	return 0;
}
