#include<stdio.h>
int main()
{
	int P;
	float T,R,SI;
	scanf("%d %f %f",&P,&T,&R);
	SI=P*T*R/100;
	printf("%.3f %d",SI,(int)SI);
	return 0;
}
