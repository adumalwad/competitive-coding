#include<stdio.h>
int main(int argc, char const *argv[])
{
	/* code */
	int a=-1,b=-9,c=5,d=-6,e=7,f=-8,s1,s2;
	float div;
	s1=a+b+c;
	s2=d+e+f;
	div=(float)s1/s2;
	printf("%f",div);

	return 0;
}