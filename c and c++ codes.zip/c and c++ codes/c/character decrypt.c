#include<stdio.h>
int main()
{
	int d,i;
	char a[5];
	scanf("%s",&a);
	scanf("%d",&d);
	for(i=0;i<5;i++)
	{
		if((a[i]+d )<='z')
		{
			printf("%c",a[i]+d);	
		}	
		else
		{
			printf("%c",a[i]+d-26);
		}
	}
	return 0;
}
