#include <stdio.h>
int main(int argc, char const *argv[])
{
	int n,m,count=0,fact=1,i,j;
	
	scanf("%d %d",&n,&m);

	for(i=0;i<=m;i++)
	{
		if((i==0) || (i==1))
		{
			fact=1;
			if((fact<=m) && (fact>=n))
			{
				count++;
			}
		}
		else
		{
			fact=1;
			for(j=i; j>1;j--)
			{
				fact=fact*j;
			}
		//	printf("%d\n",fact);
			if((fact<=m) && (fact>=n))
			{
				count++;
			}
			else if(fact>m)
			{
				count--;
				printf("%d",count);
				return 0;
			}
		}
		
	}
	count--;
	printf("%d",count);
	return 0;
}
