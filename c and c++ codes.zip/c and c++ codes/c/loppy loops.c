#include<stdio.h>
int main()
{
	int n,i,j,sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		int sum1=0;
		for(j=1;j<=i;j++)
		{
			sum1=sum1+j;
		}
		sum=sum+sum1;
	}
	printf("%d",sum);
	
	return 0;
}
