#include<stdio.h>
#include<math.h>
int main()
{
	float h,a,H;
	scanf("%f %f",&h,&a);
	//printf("%f",M_PI);
	H=h/sin((a*M_PI)/180);
	if(H>(10 *h))
	{
		printf("INF");
	}
	else
	{
		printf("%.4f %.4f %.4f",H,floor(100*H)/100,ceil(H*100)/100);
	}
	return 0;
}
