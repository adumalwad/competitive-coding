#include<stdio.h>
int main()
{
	float x1,y1,x2,y2,x3,y3,x4,y4;
	scanf("%f %f %f %f %f %f %f %f",&x1,&y1,&x2,&y2,&x3,&y3,&x4,&y4);
	float eq1=((x3-x1)/(x1-x2))-((y3-y1)/(y1-y2));
	float eq2=((x4-x1)/(x1-x2))-((y4-y1)/(y1-y2));
	if((eq1==0) && (eq2==0))
	{
		printf("both on line");
	}
	else if((eq1==0)||(eq2==0))
	{
		printf("one on line");
	}
	else if(eq1*eq2>0)
	{
		printf("lie on same side");
	}
	else
	{
		printf("both on different side");
	}
	return 0;
}
