#include<stdio.h>
int main()
{
	int HA,HB,count=0,countb=0;
	char ca,cb;
	scanf("%d",&HA);
	scanf("%c",&ca);
	
	while(ca!='|')
	{
		switch(ca)
		{
			case '+':
				{
					count++;
					HA++;
					break;
				}
			case '-':
				{
					count++;
					HA--;
					break;
				}
			case '_':
				{
					count++;
					HA--;
					break;
				}
			case '*':
				{
					count++;
					HA=HA-2;
					break;
				}
			
		}
		if(HA==0)
		{
			break;
		}
		scanf("%c",&ca);
	}
	//scanf("\n");
	scanf("%d",&HB);
	scanf("%c",&cb);
	printf("HB=%d cb=%c\n",HB,cb);
	while(cb!='|')
	{
		printf("%c %d %d\n",cb,HB,countb);
		switch(cb)
		{
			case '+':
				{
					countb++;
					HB++;
					break;
				}
			case '-':
				{
					countb++;
					HB--;
					break;
				}
			case '_':
				{
					countb++;
					HB--;
					break;
				}
			case '*':
				{
					countb++;
					HB=HB-2;
					break;
				}
			
		}
		if(HB==0)
		{
			break;
		}
		scanf("%c",&cb); 
		 //10---___*+----| 9-+-___*+----|
	}
	printf("HB=%d countb=%d\n",HB,countb);
//	printf("counta=%d countb =%d\n",count,countb);
	/*if(count>=countb)
	{
		printf("A");
	}
	else
	{
		printf("B");
	}*/
	
	return 0;	
}
