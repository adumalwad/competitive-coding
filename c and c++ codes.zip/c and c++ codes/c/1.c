#include<stdio.h>
int main(int argc, char const *argv[])
{
	int a=1,b=2,c=3,d=-5,e=10,f=1,s1,s2,sub;

	s1=a+b+c;
	s2=d+e+f;
	sub=s1-s2;
	printf("%d",sub);
	
	return 0;
}