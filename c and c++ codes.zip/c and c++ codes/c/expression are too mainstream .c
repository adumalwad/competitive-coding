#include<stdio.h>
int main()
{
 	char a[127];
 	int i=0;
 	scanf("%c",&a[0]);
 //	printf("%c",a[i]);
 	//ch=a[0];
 	while ((a[i]!=EOF) && (a[i]!='\n'))
 	{
 	//	printf("%d %c\n",i,a[i]);
 		switch (a[i])
 		{
 			case '0':
 				{
				 
 					printf("zero ");
 					break;
 				}
 			case '1':
 				{
				 
 					printf("one ");
 					break;
 				}
			case '2':
				{
					printf("two ");
					break;
				}
			case '3':
				{
					printf("three ");
					break;
				}
			case '4':
				{
					printf("four ");
					break;
				}
			case '5':
				{
					printf("five ");
					break;
				}
			case '6':
				{
					printf("six ");
					break;
				}
			case '7':
				{
					printf("seven ");
					break;
				}
			case '8':
				{
					printf("eight ");
					break;
				}
			case '9':
				{
					printf("nine ");
					break;
				}
			case '+':
				{
					printf("plus ");
					break;
				}
			case '-':
				{
					printf("minus ");
					break;
				}
			case '*':
				{
					printf("times ");
					break;
				}
			case '/':
				{
					printf("over ");
					break;
				}
			case '^':
				{
					printf("raised to ");
					break;
				}
			case '%':
				{
					printf("modulo to ");
					break;
				}
			case '=':
				{
					printf("equals ");
					break;
				}
			default:
				{
					printf("%c ",a[i]);
					break;
				}
		 }
		 
		 i=i+1;
		 if(i==10)
		 {
		 	break;
		 }
		 scanf("%c",&a[i]);
	}
	return 0;
 	
}
