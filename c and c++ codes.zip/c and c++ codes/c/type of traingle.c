#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d %d %d",&a,&b,&c);
	
	if((a>=b)&&(a>=c)&&(b+c>a)&&(a*a<(b*b+c*c)))
	{
		printf("Acute angled triangle");	
	}
	
	else if((a>=b)&&(a>=c)&&(b+c>a)&&(a*a==(b*b+c*c)))
	{
		printf("right angled triangle");	
	}
	
	else if((a>=b)&&(a>=c)&&(b+c>a)&&(a*a>(b*b+c*c)))
	{
		printf("obtuse angled triangle");	
	}
	
	else if((b>=a)&&(b>=c)&&(a+c>b)&&(b*b<(a*a+c*c)))
	{
		printf("Acute angled triangle");	
	}
	else if((b>=a)&&(b>=c)&&(a+c>b)&&(b*b==(a*a+c*c)))
	{
		printf("right angled triangle");	
	}
	else if((b>=a)&&(b>=c)&&(a+c>b)&&(b*b>(a*a+c*c)))
	{
		printf("obtuse angled triangle");	
	}
	else if((c>=a)&&(c>=b)&&(a+b>c)&&(c*c<(a*a+b*b)))
	{
		printf("Acute angled triangle");	
	}
	else if((c>=a)&&(c>=b)&&(a+b>c)&&(c*c==(a*a+b*b)))
	{
		printf("right angled triangle");	
	}
	else if((c>=a)&&(c>=b)&&(a+b>c)&&(c*c>(a*a+b*b)))
	{
		printf("Obtuse angled triangle");	
	}
	else
	{
		printf("invalid triangle");
	}

	return 0;
}
