#include<stdio.h>
int main()
{
	char ch;
	scanf("%c",&ch);
	printf("%c %d %c %d",ch,ch,ch-32,ch-32);
	return 0;
}
