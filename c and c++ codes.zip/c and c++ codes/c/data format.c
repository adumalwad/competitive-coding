#include<stdio.h>
int main()
{
	int day;
	scanf("%d",&day);
	switch(day)
	{
		case 1 || 21 || 31:
			printf("%dst",day);
			break;
		case 2 or 22:
			printf("%dnd"day);
			break;
		case 3 || 23 :
			printf("%drd",day);
			break;
		default
			printf("%dth",day);
			break;
	}
	return 0;
}
