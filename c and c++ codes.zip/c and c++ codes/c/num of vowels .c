#include<stdio.h>
int main()
{
	char a,b,c;
	int count=0;
	scanf("%c %c %c",&a,&b,&c);
	printf("%c %c %c\n",a,b,c);
	if((a=='A')||(a=='E')||(a=='I')||(a=='O')||(a=='U')||(a=='a')||(a=='e')||(a=='i')||(a=='o')||(a=='u'))
	{
		count++;
	}
	if((b=='A')||(b=='E')||(b=='I')||(b=='O')||(b=='U')||(b=='a')||(b=='e')||(b=='i')||(b=='o')||(b=='u'))
	{
		count++;
	}
	if((c=='A')||(c=='E')||(c=='I')||(c=='O')||(c=='U')||(c=='a')||(c=='e')||(c=='i')||(c=='o')||(c=='u'))
	{
		count++;
	}
	printf("%d",count);
	return 0;
}
