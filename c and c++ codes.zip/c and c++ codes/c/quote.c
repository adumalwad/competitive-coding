#include<stdio.h>
int main()
{
	printf("\"ESC201\"-\'101\'");
	return 0;
}