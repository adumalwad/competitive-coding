#include<stdio.h>
int main()
{
	int day;
	scanf("%d",&day);
	if((day==1)||(day==21) ||(day==31))
	{
		printf("%dst",day);
	}
	else if((day==2) || (day==22))
	{
		printf("%dnd",day);
	}
	else if((day==3) || (day==23))
	{
		printf("%drd",day);
	}
	else
	{
		printf("%dth",day);
	}
	return 0;
}
