#include<stdio.h>
#include<math.h>
int main()
{
	float a,h;
	scanf("%f",&a);
	h=sqrt(3)/2*a;
	printf("%.3f %d",h,(int)(sqrt(3)/2*a));
	return 0;
}
