#include<stdio.h>
int main()
{
	int i,j,n;
	char ch,c;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%c",&ch);
			//printf("i=%d j=%d %c\n",i,j,ch);
			if((i!=j) && (ch!='0'))
			{
				printf("not special diagonal matrix");;
				return 0;
			}
			if((i==j) && (i==0))
			{
				c=ch;
			}
			if((i==j) && (ch!=c))
			{
				printf("not diagonal matrix");
				return 0;
			}
			
		}
	}
	printf("diagonal martrix");
	return 0;
	
}
