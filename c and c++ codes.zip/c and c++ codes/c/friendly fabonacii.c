#include<stdio.h>
int main()
{
	int a=0,b=1,c,n,sum=1,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{	
		int k=sum,sd=0,nd=0;
	
		if((k>10) && (k<=n))
		{
			while(k!=0)
			{
				sd=sd+k%10;
				k=k/10;
				nd++;
			}
			
			if((sd%nd)==0)
			{
				printf("%d\n",sum);
			}
			
		}
		a=b;
		b=sum;
		sum=a+b;
		
	}
	return 0;
}
